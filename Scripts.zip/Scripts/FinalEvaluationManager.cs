using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class FinalEvaluationManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject finalEvaluationPanel;

    [Header("Department Scores")]
    public TextMeshProUGUI brandScoreText;
    public TextMeshProUGUI strategyScoreText;
    public TextMeshProUGUI artScoreText;
    public TextMeshProUGUI productionScoreText;

    [Header("Overall")]
    public TextMeshProUGUI grandTotalText;
    public TextMeshProUGUI recommendationText;
    public TextMeshProUGUI feedbackText;

    void Start()
    {
        if (finalEvaluationPanel != null)
            finalEvaluationPanel.SetActive(false);
    }

    public void ShowFinalEvaluation()
    {
        finalEvaluationPanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        FindAnyObjectByType<CameraFollow>()?.SetCanLook(false);

        int brandScore      = DepartmentScoreManager.brandTotalScore;
        int strategyScore   = StrategyScoreManager.strategyTotalScore;
        int artScore        = ArtScoreManager.artTotalScore;
        int productionScore = ProductionScoreManager.productionTotalScore;

        int grandTotal = brandScore + strategyScore + artScore + productionScore;

        brandScoreText.text      = $"Brand Management:         {brandScore} / 24";
        strategyScoreText.text   = $"Strategy:                       {strategyScore} / 24";
        artScoreText.text        = $"Art:                              {artScore} / 26";
        productionScoreText.text = $"Production:                   {productionScore} / 24";
        grandTotalText.text      = $"Grand Total:              {grandTotal} / 98";

        string bestDept = GetBestDepartment(
            brandScore, strategyScore, artScore, productionScore);

        recommendationText.text = bestDept;
        feedbackText.text = GetFeedback(bestDept, grandTotal);
    }

    string GetBestDepartment(int brand, int strategy, int art, int production)
    {
        // Normalise Art score to same scale as others for fair comparison
        float brandNorm      = (float)brand / 24f;
        float strategyNorm   = (float)strategy / 24f;
        float artNorm        = (float)art / 26f;
        float productionNorm = (float)production / 24f;

        float highest = Mathf.Max(brandNorm, strategyNorm,
            artNorm, productionNorm);

        if (highest == brandNorm)      return "Brand Management";
        else if (highest == strategyNorm) return "Strategy";
        else if (highest == artNorm)      return "Art";
        else                              return "Production";
    }

    string GetFeedback(string department, int grandTotal)
    {
        string opening = grandTotal >= 75
            ? "Outstanding internship performance. "
            : grandTotal >= 55
            ? "Strong internship performance. "
            : grandTotal >= 35
            ? "Good effort throughout your internship. "
            : "You completed your internship and gained valuable experience. ";

        switch (department)
        {
            case "Brand Management":
                return opening +
                    "Your strongest performance was in Brand Management. " +
                    "You demonstrated a clear understanding of brand identity, " +
                    "target audiences, and positioning strategy. " +
                    "A career as a Brand Manager could be a strong fit for you.";

            case "Strategy":
                return opening +
                    "Your strongest performance was in Strategy. " +
                    "You showed analytical thinking, strong use of frameworks " +
                    "like SWOT analysis, and a clear ability to plan campaigns. " +
                    "A career as a Strategist or Planner could suit you well.";

            case "Art":
                return opening +
                    "Your strongest performance was in the Art department. " +
                    "You demonstrated a strong visual design sensibility, " +
                    "understanding of colour, typography, and layout. " +
                    "A career as an Art Director or Designer could be your path.";

            case "Production":
                return opening +
                    "Your strongest performance was in Production. " +
                    "You showed strong organisational thinking, understanding " +
                    "of production phases, and budget and timeline management. " +
                    "A career as a Producer or Production Manager could suit you.";

            default:
                return opening +
                    "You showed balanced skills across all four departments.";
        }
    }

    public void OnFinishPressed()
{
    SceneManager.LoadScene("End Scene");
}
}