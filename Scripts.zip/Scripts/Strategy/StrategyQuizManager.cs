using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StrategyQuizManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject quizPanel;

    [Header("UI")]
    public TextMeshProUGUI quizTitleText;
    public TextMeshProUGUI questionNumberText;
    public TextMeshProUGUI statementText;
    public TextMeshProUGUI feedbackText;
    public Button trueButton;
    public Button falseButton;

    [Header("Next Stage")]
    public StrategyScoreManager strategyScoreManager;

    public static int quizScore = 0;

    private int currentQuestion = 0;
    private bool answered = false;

    private string[] statements = new string[]
    {
        "Market research helps brands understand their audience before a campaign.",
        "A SWOT analysis looks at Strengths, Weaknesses, Opportunities and Threats.",
        "Consumer insight is just about collecting numbers and statistics.",
        "SunGlow's main opportunity is the growing demand for natural drinks.",
        "Campaign planning involves setting objectives and selecting channels.",
        "A brand's weaknesses are considered external factors in a SWOT.",
        "Social media is a relevant channel for reaching SunGlow's target audience.",
        "Strategy has nothing to do with understanding consumer behaviour."
    };

    private bool[] correctAnswers = new bool[]
    {
        true,
        true,
        false,
        true,
        true,
        false,
        true,
        false
    };

    void Start()
    {
        if (quizPanel != null)
            quizPanel.SetActive(false);
    }

    public void StartQuiz()
    {
        currentQuestion = 0;
        quizScore = 0;
        quizPanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (feedbackText != null)
            feedbackText.gameObject.SetActive(false);

        DisplayQuestion(currentQuestion);
    }

    void DisplayQuestion(int index)
    {
        answered = false;
        feedbackText.gameObject.SetActive(false);

        trueButton.interactable = true;
        falseButton.interactable = true;

        questionNumberText.text = $"Question {index + 1} of {statements.Length}";
        statementText.text = statements[index];
    }

    public void OnTruePressed()
    {
        if (answered) return;
        CheckAnswer(true);
    }

    public void OnFalsePressed()
    {
        if (answered) return;
        CheckAnswer(false);
    }

    void CheckAnswer(bool playerAnswer)
    {
        answered = true;

        trueButton.interactable = false;
        falseButton.interactable = false;

        bool isCorrect = playerAnswer == correctAnswers[currentQuestion];

        feedbackText.gameObject.SetActive(true);

        if (isCorrect)
        {
            quizScore++;
            feedbackText.text = "Correct!";
        }
        else
        {
            feedbackText.text = "Incorrect!";
        }

        Invoke(nameof(NextQuestion), 2f);
    }

    void NextQuestion()
    {
        currentQuestion++;

        if (currentQuestion < statements.Length)
            DisplayQuestion(currentQuestion);
        else
            EndQuiz();
    }

    void EndQuiz()
    {
        quizPanel.SetActive(false);

        if (strategyScoreManager != null)
            strategyScoreManager.ShowScore();
        else
            Debug.LogWarning("StrategyScoreManager not assigned!");
    }
}