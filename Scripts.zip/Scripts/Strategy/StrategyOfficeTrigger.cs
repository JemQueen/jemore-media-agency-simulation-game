using UnityEngine;

public class StrategyOfficeTrigger : MonoBehaviour
{
    public StrategyTutorialManager strategyTutorialManager;

    private bool hasTriggered = false;

    void OnTriggerEnter(Collider other)
    {
        if (hasTriggered) return;

        if (other.CompareTag("Player"))
        {
            hasTriggered = true;
            Invoke(nameof(BeginDepartment), 1.5f);
            Debug.Log("Player entered Strategy Office.");
        }
    }

    void BeginDepartment()
    {
        if (strategyTutorialManager != null)
            strategyTutorialManager.StartTutorial();
        else
            Debug.LogWarning("StrategyTutorialManager not assigned!");
    }
}