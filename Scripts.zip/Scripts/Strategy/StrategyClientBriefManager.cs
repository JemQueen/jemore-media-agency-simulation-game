using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class StrategyClientBriefManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject clientBriefPanel;
    public TextMeshProUGUI briefTitleText;
    public TextMeshProUGUI briefBodyText;
    public TextMeshProUGUI pageProgressText;
    public Button nextButton;
    public Button previousButton;

    [Header("Next Stage")]
    public StrategyLongFormManager strategyLongFormManager;

    private int currentPage = 0;
    private TypewriterEffect typewriter;

    private string[] briefPages = new string[]
    {
        // page 1
        "You have already met SunGlow Beverages in the Brand Management department.\n" +
        "Now the Strategy team takes over — your job is to plan how SunGlow " +
        "will reach their audience and position themselves in the market.",

        // page 2
        "THE CHALLENGE:\n" +
        "SunGlow is entering a market dominated by large established brands. " +
        "They have a strong product but limited brand awareness and a small budget " +
        "compared to their competitors.",

        // page 3
        "THE CONSUMER:\n" +
        "Research shows that health-conscious young adults aged 18-28 are actively " +
        "looking for natural drink alternatives. They are heavily influenced by " +
        "social media, peer recommendations, and values-driven brands.",

        // page 4
        "THE COMPETITION:\n" +
        "Major competitors include large sugary drink brands and existing health " +
        "drink companies. SunGlow must find a clear gap to occupy and communicate " +
        "why they are the better choice.",

        // page 5
        "YOUR STRATEGY TASK:\n" +
        "As the Strategy intern you must analyse SunGlow's position using a " +
        "SWOT analysis and propose a campaign strategy that targets the right " +
        "audience through the right channels.",

        // page 6
        "TO COMPLETE THIS TASK YOU MUST:\n" +
        "- Identify SunGlow's key Strengths and Weaknesses\n" +
        "- Identify market Opportunities and external Threats\n" +
        "- Propose a campaign strategy with clear objectives\n" +
        "- Recommend the best channels to reach the target audience"
    };

    private string[] pageTitles = new string[]
    {
        "Strategy Brief - Overview",
        "Strategy Brief - The Challenge",
        "Strategy Brief - The Consumer",
        "Strategy Brief - The Competition",
        "Strategy Brief - Your Task",
        "Strategy Brief - Task Checklist"
    };

    private float[] pageFontSizes = new float[]
    {
        52f, 47f, 46f, 46f, 46f, 40f
    };

    public void ShowClientBrief()
    {
        currentPage = 0;
        clientBriefPanel.SetActive(true);
        typewriter = briefBodyText.GetComponent<TypewriterEffect>();

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        DisplayPage(currentPage);
    }

    void DisplayPage(int index)
    {
        briefTitleText.text = pageTitles[index];
        briefBodyText.fontSize = pageFontSizes[index];
        pageProgressText.text = $"Page {index + 1} of {briefPages.Length}";

        if (typewriter != null)
            typewriter.PlayText(briefPages[index]);
        else
            briefBodyText.text = briefPages[index];

        if (index == briefPages.Length - 1)
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Accept";
        else
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Next";

        if (previousButton != null)
            previousButton.gameObject.SetActive(index > 0);
    }

    public void OnNextPressed()
    {
        currentPage++;

        if (currentPage < briefPages.Length)
            DisplayPage(currentPage);
        else
            EndBrief();
    }

    public void OnPreviousPressed()
    {
        if (currentPage > 0)
        {
            currentPage--;
            DisplayPage(currentPage);
        }
    }

    void EndBrief()
    {
        clientBriefPanel.SetActive(false);

        if (strategyLongFormManager != null)
            strategyLongFormManager.ShowTask();
        else
            Debug.LogWarning("StrategyLongFormManager not assigned!");
    }
}