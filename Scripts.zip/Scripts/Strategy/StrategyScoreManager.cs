using UnityEngine;
using TMPro;

public class StrategyScoreManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject scorePanel;

    [Header("Score Display")]
    public TextMeshProUGUI scoreTitleText;
    public TextMeshProUGUI writtenScoreText;
    public TextMeshProUGUI miniGameScoreText;
    public TextMeshProUGUI quizScoreText;
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI summaryText;

    public static int strategyTotalScore = 0;

    private BossInteract bossInteract;

    void Start()
    {
        if (scorePanel != null)
            scorePanel.SetActive(false);

        bossInteract = FindFirstObjectByType<BossInteract>();
    }

    public void ShowScore()
    {
        scorePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        int writtenTotal  = StrategyLongFormManager.task1Score +
                            StrategyLongFormManager.task2Score;
        int miniGameTotal = StrategyMiniGameManager.miniGameScore;
        int quizTotal     = StrategyQuizManager.quizScore;
        int total         = writtenTotal + miniGameTotal + quizTotal;

        strategyTotalScore = total;

        writtenScoreText.text  = $"Written Task:       {writtenTotal} / 10";
        miniGameScoreText.text = $"SWOT Sorting:       {miniGameTotal} / 6";
        quizScoreText.text     = $"Quiz:               {quizTotal} / 8";
        totalScoreText.text    = $"Department Total:   {total} / 24";
        summaryText.text       = "Your Strategy score has been recorded. " +
                                 "Complete all four departments to see your " +
                                 "final evaluation and recommended career path.";
    }

    public void OnContinuePressed()
    {
        scorePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        FindFirstObjectByType<PlayerMovement>().enabled = true;

        if (bossInteract != null)
            bossInteract.OnStrategyManagementComplete();
        else
            Debug.LogWarning("BossInteract not found!");
    }
}