using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class StrategyTutorialManager : MonoBehaviour
{
    [Header("Concept Data")]
    public ConceptData[] concepts;

    [Header("Intro Panel")]
    public GameObject introPanel;
    public TextMeshProUGUI introTitleText;
    public TextMeshProUGUI introBodyText;
    public TextMeshProUGUI introNoteText;

    [Header("Tutorial Panel")]
    public GameObject tutorialPanel;
    public TextMeshProUGUI conceptTitleText;
    public TextMeshProUGUI conceptBodyText;
    public TextMeshProUGUI exampleText;
    public TextMeshProUGUI progressText;
    public Button nextButton;

    [Header("Next Stage")]
    public StrategyClientBriefManager strategyClientBriefManager;

    private int currentIndex = 0;

    void Start()
    {
        if (introPanel != null)
            introPanel.SetActive(false);

        if (tutorialPanel != null)
            tutorialPanel.SetActive(false);
    }

    public void StartTutorial()
    {
        currentIndex = 0;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        FindAnyObjectByType<CameraFollow>()?.SetCanLook(false);

        ShowIntroPanel();
    }

    void ShowIntroPanel()
    {
        introPanel.SetActive(true);
        tutorialPanel.SetActive(false);

        introTitleText.text = "Welcome to Strategy";

        introBodyText.text = "";
        introNoteText.text = "";

        StartCoroutine(TypeIntroSequentially());
    }

    IEnumerator TypeIntroSequentially()
    {
        TypewriterEffect bodyTypewriter = introBodyText.GetComponent<TypewriterEffect>();
        string bodyContent = "The Strategy department is the engine behind every successful campaign. " +
                             "Strategists research the market, understand consumers deeply, and build " +
                             "plans that guide every creative and production decision.\n\n" +
                             "In this department, your supervisor will walk you through four essential " +
                             "concepts that every Strategist must understand before developing " +
                             "a campaign plan for a client.";

        if (bodyTypewriter != null)
        {
            bodyTypewriter.PlayText(bodyContent);
            yield return new WaitUntil(() => !bodyTypewriter.IsTyping());
        }
        else
        {
            introBodyText.text = bodyContent;
        }

        // Natural pause before typing the note
        yield return new WaitForSeconds(0.4f);

        TypewriterEffect noteTypewriter = introNoteText.GetComponent<TypewriterEffect>();
        string noteContent = "Pay close attention — these concepts will appear in your client " +
                             "brief, written task, and final quiz.";

        if (noteTypewriter != null)
        {
            noteTypewriter.PlayText(noteContent);
        }
        else
        {
            introNoteText.text = noteContent;
        }
    }

    public void OnBeginPressed()
    {
        StopAllCoroutines(); 

        introPanel.SetActive(false);
        tutorialPanel.SetActive(true);
        DisplayConcept(0);
    }

    void DisplayConcept(int index)
    {
        ConceptData concept = concepts[index];
        conceptTitleText.text = concept.conceptTitle;
        progressText.text = $"Concept {index + 1} of {concepts.Length}";
        exampleText.text = "";

        if (index == concepts.Length - 1)
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Proceed";
        else
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Next";

        StartCoroutine(TypeConceptSequentially(concept));
    }

    IEnumerator TypeConceptSequentially(ConceptData concept)
    {
        TypewriterEffect bodyTypewriter = conceptBodyText.GetComponent<TypewriterEffect>();

        if (bodyTypewriter != null)
        {
            bodyTypewriter.PlayText(concept.conceptExplanation);
            yield return new WaitUntil(() => !bodyTypewriter.IsTyping());
        }
        else
        {
            conceptBodyText.text = concept.conceptExplanation;
        }

        yield return new WaitForSeconds(0.4f);

        TypewriterEffect exampleTypewriter = exampleText.GetComponent<TypewriterEffect>();

        if (exampleTypewriter != null)
            exampleTypewriter.PlayText("Example:\n" + concept.realWorldExample);
        else
            exampleText.text = "Example:\n" + concept.realWorldExample;
    }

    public void OnNextButtonPressed()
    {
        currentIndex++;

        if (currentIndex < concepts.Length)
            DisplayConcept(currentIndex);
        else
            EndTutorial();
    }

    void EndTutorial()
    {
        tutorialPanel.SetActive(false);
        Debug.Log("Strategy tutorial complete");

        if (strategyClientBriefManager != null)
            strategyClientBriefManager.ShowClientBrief();
        else
            Debug.LogWarning("StrategyClientBriefManager not assigned!");
    }
}