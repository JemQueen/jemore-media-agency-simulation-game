using UnityEngine;
using TMPro;

public class StrategyLongFormFeedbackManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject feedbackPanel;

    [Header("Task 1 Results")]
    public TextMeshProUGUI task1ScoreText;
    public TextMeshProUGUI task1FeedbackText;

    [Header("Task 2 Results")]
    public TextMeshProUGUI task2ScoreText;
    public TextMeshProUGUI task2FeedbackText;

    [Header("Overall")]
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI overallFeedbackText;

    [Header("Next Stage")]
    public StrategyMiniGameManager strategyMiniGameManager;

    public static int longFormTotalScore = 0;

    void Start()
    {
        if (feedbackPanel != null)
            feedbackPanel.SetActive(false);
    }

    public void ShowFeedback(int score1, int score2, string[] answers)
    {
        feedbackPanel.SetActive(true);

        int total = score1 + score2;
        longFormTotalScore = total;

        task1ScoreText.text = $"SWOT Analysis — {score1} / 5";
        task1FeedbackText.text = GetTask1Feedback(score1);

        task2ScoreText.text = $"Campaign Strategy — {score2} / 5";
        task2FeedbackText.text = GetTask2Feedback(score2);

        totalScoreText.text = $"Written Task Total:  {total} / 10";
        overallFeedbackText.text = GetOverallFeedback(total);
    }

    string GetTask1Feedback(int score)
    {
        if (score >= 5)
            return "Excellent SWOT analysis. You identified clear internal " +
                   "and external factors relevant to SunGlow's position.";
        else if (score >= 4)
            return "Good analysis. You covered most SWOT elements. " +
                   "Try to be more specific about external threats and opportunities.";
        else if (score >= 3)
            return "Decent effort. Make sure you address all four SWOT " +
                   "components with specific examples from the brief.";
        else
            return "Your SWOT needs more depth. Think about what SunGlow " +
                   "does well, where they struggle, market trends, and competitors.";
    }

    string GetTask2Feedback(int score)
    {
        if (score >= 5)
            return "Outstanding strategy proposal. You clearly defined " +
                   "objectives, audience, and channels in a coherent plan.";
        else if (score >= 4)
            return "Strong proposal. Your strategy has good direction. " +
                   "Adding more specific channel recommendations would strengthen it.";
        else if (score >= 3)
            return "Your proposal shows strategic thinking but needs more " +
                   "detail on how you would reach the target audience.";
        else
            return "A campaign strategy needs clear objectives, a defined " +
                   "audience, and specific channels. Revisit the brief and try again.";
    }

    string GetOverallFeedback(int total)
    {
        if (total >= 9)
            return "Outstanding written performance in Strategy. " +
                   "You think like a strategist.";
        else if (total >= 7)
            return "Good performance. You have a solid strategic mindset " +
                   "and can apply frameworks to real briefs.";
        else if (total >= 5)
            return "Decent effort. Keep practising applying strategic " +
                   "frameworks to real client situations.";
        else
            return "Strategy challenged you — review the SWOT and campaign " +
                   "planning concepts and apply them to SunGlow specifically.";
    }

    public void OnContinuePressed()
    {
        feedbackPanel.SetActive(false);

        if (strategyMiniGameManager != null)
            strategyMiniGameManager.StartMiniGame();
        else
            Debug.LogWarning("StrategyMiniGameManager not assigned!");
    }
}