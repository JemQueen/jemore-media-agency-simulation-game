using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StrategyMiniGameManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject miniGamePanel;

    [Header("UI")]
    public TextMeshProUGUI resultText;
    public Button submitButton;

    [Header("Drop Zones — drag the Zone GameObject")]
    public DropZone strengthZone;
    public DropZone weaknessZone;
    public DropZone opportunityZone;
    public DropZone threatZone;

    [Header("Cards")]
    public StrategyCard[] allCards;

    [Header("Next Stage")]
    public StrategyQuizManager strategyQuizManager;

    public static int miniGameScore = 0;

    void Start()
    {
        if (miniGamePanel != null)
            miniGamePanel.SetActive(false);

        if (resultText != null)
            resultText.gameObject.SetActive(false);
    }

    public void StartMiniGame()
    {
        miniGamePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (resultText != null)
            resultText.gameObject.SetActive(false);

        submitButton.interactable = true;
    }

    public void OnCheckAnswers()
    {
        int correct = 0;

        foreach (StrategyCard card in allCards)
        {
            if (card.currentZone == null)
            {
                Debug.Log($"{card.cardLabel} — not placed");
                continue;
            }

            bool isCorrect = false;

            if (card.correctZone == SWOTZone.Strength &&
                card.currentZone == strengthZone.contentContainer)
                isCorrect = true;
            else if (card.correctZone == SWOTZone.Weakness &&
                card.currentZone == weaknessZone.contentContainer)
                isCorrect = true;
            else if (card.correctZone == SWOTZone.Opportunity &&
                card.currentZone == opportunityZone.contentContainer)
                isCorrect = true;
            else if (card.correctZone == SWOTZone.Threat &&
                card.currentZone == threatZone.contentContainer)
                isCorrect = true;

            Debug.Log($"{card.cardLabel} | " +
                      $"currentZone: {card.currentZone?.name} | " +
                      $"expected: {strengthZone.contentContainer?.name} | " +
                      $"correct: {isCorrect}");

            if (isCorrect) correct++;
        }

        miniGameScore = correct;

        resultText.gameObject.SetActive(true);
        resultText.text =
            $"You sorted {correct} out of {allCards.Length} correctly!";

        submitButton.interactable = false;
        Invoke(nameof(ProceedToQuiz), 3f);
    }

    void ProceedToQuiz()
    {
        miniGamePanel.SetActive(false);

        if (strategyQuizManager != null)
            strategyQuizManager.StartQuiz();
        else
            Debug.LogWarning("StrategyQuizManager not assigned!");
    }
}