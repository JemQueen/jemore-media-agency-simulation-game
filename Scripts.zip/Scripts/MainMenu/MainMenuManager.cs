using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour
{
    // Name of your main game scene exactly as saved
    public string gameSceneName = "Demo 1 - Office Set 1";

    public void OnStartPressed()
    {
        SceneManager.LoadScene(gameSceneName);
    }

    public void OnQuitPressed()
    {
        Debug.Log("Quitting game...");
        Application.Quit();
    }
}