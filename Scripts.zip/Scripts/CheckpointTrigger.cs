using UnityEngine;

public class CheckpointTrigger : MonoBehaviour
{
    [Header("Optional - for Brand Office checkpoint only")]
    public GameObject followBossText;
    public bool reEnablePlayerInteraction = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // Hide follow text if assigned
            if (followBossText != null)
                followBossText.SetActive(false);

            if (reEnablePlayerInteraction)
            {
                PlayerInteraction pi = FindFirstObjectByType<PlayerInteraction>();
                if (pi != null)
                    pi.enabled = true;
            }

            gameObject.SetActive(false);
            Debug.Log("Checkpoint reached.");
        }
    }
}