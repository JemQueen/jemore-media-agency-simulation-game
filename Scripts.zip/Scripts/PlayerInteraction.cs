using UnityEngine;
using TMPro;

public class PlayerInteraction : MonoBehaviour
{
    public float interactionRange = 3f;
    public TextMeshProUGUI interactionText;

    private IInteractable currentInteractable;
    private bool isInteracting = false;

    void Start()
    {
        interactionText.gameObject.SetActive(false);
    }

    void Update()
    {
        CheckForInteractable();

        if (currentInteractable != null &&
            Input.GetKeyDown(KeyCode.E) && !isInteracting)
        {
            isInteracting = true;
            currentInteractable.Interact();
            interactionText.gameObject.SetActive(false);
        }
    }

    void CheckForInteractable()
    {
        if (isInteracting) return;

        Collider[] colliders = Physics.OverlapSphere(
            transform.position, interactionRange);

        currentInteractable = null;

        foreach (Collider collider in colliders)
        {
            IInteractable interactable =
                collider.GetComponent<IInteractable>();

            if (interactable != null)
            {
                BossInteract boss =
                    collider.GetComponent<BossInteract>();
                if (boss != null && !boss.IsReadyToInteract())
                    continue;

                currentInteractable = interactable;
                interactionText.gameObject.SetActive(true);
                interactionText.text = "Press E to Interact";
                return;
            }
        }

        interactionText.gameObject.SetActive(false);
    }

    public void EndInteraction()
    {
        isInteracting = false;
        currentInteractable = null;
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, interactionRange);
    }
}