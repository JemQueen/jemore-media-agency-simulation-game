using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ArtClientBriefManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject clientBriefPanel;
    public TextMeshProUGUI briefTitleText;
    public TextMeshProUGUI briefBodyText;
    public TextMeshProUGUI pageProgressText;
    public Button nextButton;
    public Button previousButton;

    [Header("Next Stage")]
    public ArtLongFormManager artLongFormManager;

    private int currentPage = 0;
    private TypewriterEffect typewriter;

    private string[] briefPages = new string[]
    {
        // page 1
        "The Brand and Strategy teams have completed their work on SunGlow Beverages.\n" +
        "Now it is the Art department's turn to bring the brand to life visually.\n" +
        "Your job is to design the visual identity for SunGlow's campaign.",

        // page 2
        "THE BRAND PERSONALITY:\n" +
        "SunGlow is energetic, fresh, and approachable.\n" +
        "They target health-conscious young adults aged 18-28 who want " +
        "something fun and natural.",

        // page 3
        "THE VISUAL CHALLENGE:\n" +
        "SunGlow needs a visual identity that stands out on social media, " +
        "in stores, and on billboards.\n" +
        "The visuals must feel vibrant and modern without looking artificial " +
        "or overly clinical.",

        // page 4
        "COLOUR DIRECTION:\n" +
        "The team has agreed SunGlow should use warm, natural colours.\n" +
        "Think oranges, yellows, and greens that feel fresh and full of energy " +
        "rather than cold or corporate.",

        // page 5
        "LAYOUT DIRECTION:\n" +
        "SunGlow's advertisements should lead with the product, " +
        "supported by a bold headline and a clear call to action.\n" +
        "The layout should be clean and uncluttered — letting the product speak.",

        // page 6
        "YOUR ART TASK:\n" +
        "- Describe the visual design principles you would apply to SunGlow\n" +
        "- Propose a typography approach for their brand\n" +
        "- Select and justify a colour palette\n" +
        "- Describe how you would lay out a SunGlow advertisement"
    };

    private string[] pageTitles = new string[]
    {
        "Art Brief — Overview",
        "Art Brief — Brand Personality",
        "Art Brief — The Visual Challenge",
        "Art Brief — Colour Direction",
        "Art Brief — Layout Direction",
        "Art Brief — Your Task"
    };

    private float[] pageFontSizes = new float[]
    {
        50f, 45f, 45f, 46f, 45f, 40f
    };

    public void ShowClientBrief()
    {
        currentPage = 0;
        clientBriefPanel.SetActive(true);
        typewriter = briefBodyText.GetComponent<TypewriterEffect>();

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        DisplayPage(currentPage);
    }

    void DisplayPage(int index)
    {
        briefTitleText.text = pageTitles[index];
        briefBodyText.fontSize = pageFontSizes[index];
        pageProgressText.text = $"Page {index + 1} of {briefPages.Length}";

        if (typewriter != null)
            typewriter.PlayText(briefPages[index]);
        else
            briefBodyText.text = briefPages[index];

        if (index == briefPages.Length - 1)
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Accept";
        else
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Next";

        if (previousButton != null)
            previousButton.gameObject.SetActive(index > 0);
    }

    public void OnNextPressed()
    {
        currentPage++;

        if (currentPage < briefPages.Length)
            DisplayPage(currentPage);
        else
            EndBrief();
    }

    public void OnPreviousPressed()
    {
        if (currentPage > 0)
        {
            currentPage--;
            DisplayPage(currentPage);
        }
    }

    void EndBrief()
    {
        clientBriefPanel.SetActive(false);

        if (artLongFormManager != null)
            artLongFormManager.ShowTask();
        else
            Debug.LogWarning("ArtLongFormManager not assigned!");
    }
}