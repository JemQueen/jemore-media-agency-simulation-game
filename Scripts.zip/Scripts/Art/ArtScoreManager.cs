using UnityEngine;
using TMPro;

public class ArtScoreManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject scorePanel;

    [Header("Score Display")]
    public TextMeshProUGUI scoreTitleText;
    public TextMeshProUGUI writtenScoreText;
    public TextMeshProUGUI miniGame1ScoreText;
    public TextMeshProUGUI miniGame2ScoreText;
    public TextMeshProUGUI quizScoreText;
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI summaryText;

    public static int artTotalScore = 0;

    private BossInteract bossInteract;

    void Start()
    {
        if (scorePanel != null)
            scorePanel.SetActive(false);

        bossInteract = FindFirstObjectByType<BossInteract>();
    }

    public void ShowScore()
    {
        scorePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        int writtenTotal   = ArtLongFormManager.task1Score +
                             ArtLongFormManager.task2Score;
        int miniGame1Total = ArtMiniGame1Manager.miniGame1Score;
        int miniGame2Total = ArtMiniGame2Manager.miniGame2Score;
        int quizTotal      = ArtQuizManager.quizScore;
        int total          = writtenTotal + miniGame1Total +
                             miniGame2Total + quizTotal;

        artTotalScore = total;

        writtenScoreText.text    = $"Written Task:          {writtenTotal} / 10";
        miniGame1ScoreText.text  = $"Colour Palette:        {miniGame1Total} / 3";
        miniGame2ScoreText.text  = $"Layout Sorter:         {miniGame2Total} / 5";
        quizScoreText.text       = $"Quiz:                  {quizTotal} / 8";
        totalScoreText.text      = $"Department Total:      {total} / 26";
        summaryText.text         =
            "Your Art department score has been recorded. " +
            "Complete all four departments to see your final " +
            "evaluation and recommended career path.";
    }

    public void OnContinuePressed()
    {
        scorePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        FindFirstObjectByType<PlayerMovement>().enabled = true;

        if (bossInteract != null)
            bossInteract.OnArtManagementComplete();
        else
            Debug.LogWarning("BossInteract not found!");
    }
}