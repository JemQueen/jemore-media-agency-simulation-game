using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ArtMiniGame1Manager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject miniGame1Panel;

    [Header("UI")]
    public TextMeshProUGUI feedbackText;
    public Button continueButton;
    public Button palette1Button;
    public Button palette2Button;
    public Button palette3Button;

    [Header("Next Stage")]
    public ArtMiniGame2Manager artMiniGame2Manager;

    public static int miniGame1Score = 0;

    // Correct answer is Palette 1 — warm oranges and yellows
    private int correctPalette = 1;

    void Start()
    {
        if (miniGame1Panel != null)
            miniGame1Panel.SetActive(false);
    }

    public void StartMiniGame()
    {
        miniGame1Panel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        feedbackText.gameObject.SetActive(false);
        continueButton.gameObject.SetActive(false);
    }

    public void OnPalette1Selected()
    {
        EvaluateChoice(1);
    }

    public void OnPalette2Selected()
    {
        EvaluateChoice(2);
    }

    public void OnPalette3Selected()
    {
        EvaluateChoice(3);
    }

    void EvaluateChoice(int selected)
    {
        palette1Button.interactable = false;
        palette2Button.interactable = false;
        palette3Button.interactable = false;

        feedbackText.gameObject.SetActive(true);

        if (selected == correctPalette)
        {
            miniGame1Score = 3;
            feedbackText.text =
                "Correct!";
         }
        else if (selected == 2)
        {
            miniGame1Score = 1;
            feedbackText.text =
                "Not quite.";

        }
        else
        {
            miniGame1Score = 1;
            feedbackText.text =
                "Not quite.";

        }

        continueButton.gameObject.SetActive(true);
    }

    public void OnContinuePressed()
    {
        miniGame1Panel.SetActive(false);

        if (artMiniGame2Manager != null)
            artMiniGame2Manager.StartMiniGame();
        else
            Debug.LogWarning("ArtMiniGame2Manager not assigned!");
    }
}