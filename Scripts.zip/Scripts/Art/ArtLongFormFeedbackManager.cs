using UnityEngine;
using TMPro;

public class ArtLongFormFeedbackManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject feedbackPanel;

    [Header("Task 1 Results")]
    public TextMeshProUGUI task1ScoreText;
    public TextMeshProUGUI task1FeedbackText;

    [Header("Task 2 Results")]
    public TextMeshProUGUI task2ScoreText;
    public TextMeshProUGUI task2FeedbackText;

    [Header("Overall")]
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI overallFeedbackText;

    [Header("Next Stage")]
    public ArtMiniGame1Manager artMiniGame1Manager;

    public static int longFormTotalScore = 0;

    void Start()
    {
        if (feedbackPanel != null)
            feedbackPanel.SetActive(false);
    }

    public void ShowFeedback(int score1, int score2, string[] answers)
    {
        feedbackPanel.SetActive(true);

        int total = score1 + score2;
        longFormTotalScore = total;

        task1ScoreText.text = $"Visual Identity — {score1} / 5";
        task1FeedbackText.text = GetTask1Feedback(score1);

        task2ScoreText.text = $"Layout Description — {score2} / 5";
        task2FeedbackText.text = GetTask2Feedback(score2);

        totalScoreText.text = $"Written Task Total:  {total} / 10";
        overallFeedbackText.text = GetOverallFeedback(total);
    }

    string GetTask1Feedback(int score)
    {
        if (score >= 5)
            return "Excellent visual identity proposal. Your colour, " +
                   "typography, and design principle choices are well " +
                   "justified and suited to SunGlow's personality.";
        else if (score >= 4)
            return "Strong proposal. You covered most visual elements well. " +
                   "Adding more justification for your colour choices " +
                   "would strengthen it further.";
        else if (score >= 3)
            return "Decent effort. Try to address all visual elements — " +
                   "colour, font, and design principles — with specific " +
                   "reasoning tied to the brand.";
        else
            return "Your visual identity needs more detail. Think about " +
                   "what colours, fonts, and design principles best " +
                   "represent SunGlow's energetic personality.";
    }

    string GetTask2Feedback(int score)
    {
        if (score >= 5)
            return "Outstanding layout description. You clearly understood " +
                   "visual hierarchy and how to guide the viewer through " +
                   "the advertisement.";
        else if (score >= 4)
            return "Good layout thinking. Your placement decisions make " +
                   "sense. Consider explaining more about why the viewer's " +
                   "eye follows your chosen path.";
        else if (score >= 3)
            return "Your layout shows some understanding. Make sure you " +
                   "address where each key element goes and why it " +
                   "appears in that position.";
        else
            return "A good advertisement layout needs clear hierarchy. " +
                   "Think about logo, headline, product image, and call " +
                   "to action placement.";
    }

    string GetOverallFeedback(int total)
    {
        if (total >= 9)
            return "Outstanding written performance in Art. You think " +
                   "like a visual creative.";
        else if (total >= 7)
            return "Good performance. You have a strong visual design " +
                   "mindset and can apply it to real briefs.";
        else if (total >= 5)
            return "Decent effort. Keep building your understanding of " +
                   "visual design principles and how they apply to brands.";
        else
            return "Art challenged you — review the design concepts and " +
                   "think about how each one would look in a SunGlow ad.";
    }

    public void OnContinuePressed()
    {
        feedbackPanel.SetActive(false);

        if (artMiniGame1Manager != null)
            artMiniGame1Manager.StartMiniGame();
        else
            Debug.LogWarning("ArtMiniGame1Manager not assigned!");
    }
}