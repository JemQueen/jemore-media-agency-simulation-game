using UnityEngine;

public class ArtOfficeTrigger : MonoBehaviour
{
    public ArtTutorialManager artTutorialManager;

    private bool hasTriggered = false;

    void Start()
    {
        gameObject.SetActive(false);
    }

    void OnTriggerEnter(Collider other)
    {
        if (hasTriggered) return;

        if (other.CompareTag("Player"))
        {
            hasTriggered = true;

            // Hide any leftover UI
            PlayerInteraction pi = FindFirstObjectByType<PlayerInteraction>();
            if (pi != null)
                pi.enabled = false;

            Invoke(nameof(BeginDepartment), 1.5f);
            Debug.Log("Player entered Art Office.");
        }
    }

    void BeginDepartment()
    {
        if (artTutorialManager != null)
            artTutorialManager.StartTutorial();
        else
            Debug.LogWarning("ArtTutorialManager not assigned!");
    }
}