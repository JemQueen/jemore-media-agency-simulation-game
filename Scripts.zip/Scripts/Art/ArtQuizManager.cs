using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ArtQuizManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject quizPanel;

    [Header("UI")]
    public TextMeshProUGUI quizTitleText;
    public TextMeshProUGUI questionNumberText;
    public TextMeshProUGUI statementText;
    public TextMeshProUGUI feedbackText;
    public Button trueButton;
    public Button falseButton;

    [Header("Next Stage")]
    public ArtScoreManager artScoreManager;

    public static int quizScore = 0;

    private int currentQuestion = 0;
    private bool answered = false;

    private string[] statements = new string[]
    {
        "Warm colours like orange and yellow communicate energy and freshness.",
        "Typography has no impact on how a brand is perceived.",
        "Visual hierarchy guides the viewer's eye through an advertisement.",
        "SunGlow should use dark corporate colours to look professional.",
        "Balance and contrast are key principles of visual design.",
        "The logo should always be placed in the most visible position.",
        "A call to action tells the audience what to do next.",
        "Layout and composition have no effect on how effective an ad is."
    };

    private bool[] correctAnswers = new bool[]
    {
        true,
        false,
        true,
        false,
        true,
        true,
        true,
        false
    };

    void Start()
    {
        if (quizPanel != null)
            quizPanel.SetActive(false);
    }

    public void StartQuiz()
    {
        currentQuestion = 0;
        quizScore = 0;
        quizPanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (feedbackText != null)
            feedbackText.gameObject.SetActive(false);

        DisplayQuestion(currentQuestion);
    }

    void DisplayQuestion(int index)
    {
        answered = false;
        feedbackText.gameObject.SetActive(false);

        trueButton.interactable = true;
        falseButton.interactable = true;

        questionNumberText.text = $"Question {index + 1} of {statements.Length}";
        statementText.text = statements[index];
    }

    public void OnTruePressed()
    {
        if (answered) return;
        CheckAnswer(true);
    }

    public void OnFalsePressed()
    {
        if (answered) return;
        CheckAnswer(false);
    }

    void CheckAnswer(bool playerAnswer)
    {
        answered = true;

        trueButton.interactable = false;
        falseButton.interactable = false;

        bool isCorrect = playerAnswer == correctAnswers[currentQuestion];

        feedbackText.gameObject.SetActive(true);

        if (isCorrect)
        {
            quizScore++;
            feedbackText.text = "Correct!";
        }
        else
        {
            feedbackText.text = "Incorrect!" ;
         }

        Invoke(nameof(NextQuestion), 2f);
    }

    void NextQuestion()
    {
        currentQuestion++;

        if (currentQuestion < statements.Length)
            DisplayQuestion(currentQuestion);
        else
            EndQuiz();
    }

    void EndQuiz()
    {
        quizPanel.SetActive(false);

        if (artScoreManager != null)
            artScoreManager.ShowScore();
        else
            Debug.LogWarning("ArtScoreManager not assigned!");
    }
}