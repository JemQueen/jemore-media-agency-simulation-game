using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ArtMiniGame2Manager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject miniGame2Panel;

    [Header("UI")]
    public TextMeshProUGUI resultText;
    public Button submitButton;

    [Header("Drop Zones — assign the Zone GameObject itself")]
    public LayoutDropZone topLeftZone;
    public LayoutDropZone topZone;
    public LayoutDropZone middleZone;
    public LayoutDropZone bottomZone;
    public LayoutDropZone bottomRightZone;

    [Header("Cards")]
    public LayoutCard[] allCards;

    [Header("Next Stage")]
    public ArtQuizManager artQuizManager;

    public static int miniGame2Score = 0;

    void Start()
    {
        if (miniGame2Panel != null)
            miniGame2Panel.SetActive(false);

        if (resultText != null)
            resultText.gameObject.SetActive(false);
    }

    public void StartMiniGame()
    {
        miniGame2Panel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (resultText != null)
            resultText.gameObject.SetActive(false);

        submitButton.interactable = true;
    }

    public void OnCheckLayout()
    {
        int correct = 0;

        foreach (LayoutCard card in allCards)
        {
            if (card.currentZone == null)
            {
                Debug.Log($"{card.cardLabel} — not placed");
                continue;
            }

            bool isCorrect = false;

            // Check by comparing the card's current zone to each
            // zone's contentContainer
            if (card.correctPosition == LayoutPosition.TopLeft &&
                card.currentZone == topLeftZone.contentContainer)
                isCorrect = true;
            else if (card.correctPosition == LayoutPosition.Top &&
                card.currentZone == topZone.contentContainer)
                isCorrect = true;
            else if (card.correctPosition == LayoutPosition.Middle &&
                card.currentZone == middleZone.contentContainer)
                isCorrect = true;
            else if (card.correctPosition == LayoutPosition.Bottom &&
                card.currentZone == bottomZone.contentContainer)
                isCorrect = true;
            else if (card.correctPosition == LayoutPosition.BottomRight &&
                card.currentZone == bottomRightZone.contentContainer)
                isCorrect = true;

            Debug.Log($"{card.cardLabel} — correct: {isCorrect}");

            if (isCorrect) correct++;
        }

        miniGame2Score = correct;

        resultText.gameObject.SetActive(true);
        resultText.text =
            $"You placed {correct} out of {allCards.Length} elements correctly!";

        submitButton.interactable = false;

        Invoke(nameof(ProceedToQuiz), 3f);
    }

    void ProceedToQuiz()
    {
        miniGame2Panel.SetActive(false);

        if (artQuizManager != null)
            artQuizManager.StartQuiz();
        else
            Debug.LogWarning("ArtQuizManager not assigned!");
    }
}