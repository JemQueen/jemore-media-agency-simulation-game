using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;
    public Vector3 offset = new Vector3(0, 2, -4);
    public float smoothSpeed = 10f;
    public float collisionOffset = 0.2f;

    public bool canLook = true;

    float yaw;
    float pitch = 10f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void LateUpdate()
    {
        if (canLook)
        {
            yaw += Input.GetAxis("Mouse X");
            pitch -= Input.GetAxis("Mouse Y");

            pitch = Mathf.Clamp(pitch, -10f, 35f);
        }

        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0);

        Vector3 desiredPosition = player.position + rotation * offset;

        Vector3 direction = desiredPosition - player.position;
        float distance = direction.magnitude;

        if (Physics.Raycast(
            player.position,
            direction.normalized,
            out RaycastHit hit,
            distance,
            ~0,
            QueryTriggerInteraction.Ignore))
        {
            desiredPosition = player.position + direction.normalized * (hit.distance - collisionOffset);
        }

        transform.position = Vector3.Lerp(
            transform.position,
            desiredPosition,
            smoothSpeed * Time.deltaTime
        );

        transform.LookAt(player.position + Vector3.up * 1.5f);
    }

    public void SetCanLook(bool value)
    {
        canLook = value;
    }
}