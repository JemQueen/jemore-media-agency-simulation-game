using UnityEngine;

[CreateAssetMenu(fileName = "NewConcept", menuName = "BrandDepartment/Concept")]

public class ConceptData : ScriptableObject
{
    public string conceptTitle;

    [TextArea(3, 6)]
    public string conceptExplanation;

    [TextArea(2, 4)]
    public string realWorldExample;
}