using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class LongFormTaskManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject longFormPanel;

    [Header("Task Display")]
    public TextMeshProUGUI taskBadgeText;
    public TextMeshProUGUI taskTitleText;
    public TextMeshProUGUI instructionText;
    public TextMeshProUGUI hintText;

    [Header("Input")]
    public TMP_InputField answerInputField;

    [Header("Button")]
    public Button submitButton;

    [Header("Next Stage")]
    public LongFormFeedbackManager feedbackManager;

    public static int task1Score = 0;
    public static int task2Score = 0;

    private int currentTask = 0;
    private string[] taskAnswers = new string[2];

    private PlayerMovement playerMovement;

    private string[] taskBadges = new string[]
    {
        "TASK  01 OF 02",
        "TASK  02 OF 02"
    };

    private string[] taskTitles = new string[]
    {
        "Target Audience Profile",
        "Brand Positioning Statement"
    };

    private string[] taskInstructions = new string[]
    {
        "Based on the SunGlow brief, write a target audience profile.\n" +
        "Describe who they are, what they value, and why SunGlow appeals to them.",

        "Write a brand positioning statement for SunGlow Beverages.\n" +
        "Your statement should clearly communicate who the brand is for, " +
        "what it offers, and why it is different from competitors."
    };

    private string[] taskHints = new string[]
    {
        "Think about: age range, lifestyle, values, and buying behaviour.",
        "Think about: audience, product benefit, and point of difference."
    };

    private string[][] taskKeywords = new string[][]
    {
        new string[] { "18", "young", "adult", "health", "natural", "active",
                       "social", "fun", "lifestyle", "conscious", "28" },


        new string[] { "natural", "healthy", "alternative", "sugary", "different",
                       "young", "energetic", "fresh", "audience", "position" }
    };

    void Start()
    {
        if (longFormPanel != null)
            longFormPanel.SetActive(false);

        playerMovement = FindFirstObjectByType<PlayerMovement>();
    }

    public void ShowTask()
    {
        currentTask = 0;
        longFormPanel.SetActive(true);

        if (playerMovement != null)
            playerMovement.enabled = false;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        DisplayTask(currentTask);
    }

    void DisplayTask(int index)
    {
        taskBadgeText.text = taskBadges[index];
        taskTitleText.text = taskTitles[index];
        instructionText.text = taskInstructions[index];
        hintText.text = "Hint: " + taskHints[index];
        answerInputField.text = "";
        answerInputField.textComponent.color = Color.black;

        if (index == taskTitles.Length - 1)
            submitButton.GetComponentInChildren<TextMeshProUGUI>().text = "Submit";
        else
            submitButton.GetComponentInChildren<TextMeshProUGUI>().text = "Submit";

        // Force focus after a short delay so Unity UI is ready
        StartCoroutine(FocusInputField());
    }

    IEnumerator FocusInputField()
    {
        // Wait two frames for the UI to fully activate
        yield return null;
        yield return null;

        answerInputField.interactable = true;
        answerInputField.ActivateInputField();
    }

    public void OnSubmitPressed()
    {
        string answer = answerInputField.text.Trim();

        if (answer.Length < 20)
        {
            hintText.text = "Please write a more detailed response before submitting.";
            return;
        }

        taskAnswers[currentTask] = answer;

        int score = ScoreAnswer(answer, taskKeywords[currentTask]);

        if (currentTask == 0)
            task1Score = score;
        else
            task2Score = score;

        currentTask++;

        if (currentTask < taskTitles.Length)
        {
            DisplayTask(currentTask);
        }
        else
        {
            EndLongForm();
        }
    }

    int ScoreAnswer(string answer, string[] keywords)
    {
        string lowerAnswer = answer.ToLower();
        int score = 0;

        foreach (string keyword in keywords)
        {
            if (lowerAnswer.Contains(keyword.ToLower()))
                score++;
        }

        float ratio = (float)score / keywords.Length;

        if (ratio >= 0.7f) return 5;
        else if (ratio >= 0.5f) return 4;
        else if (ratio >= 0.3f) return 3;
        else if (ratio >= 0.15f) return 2;
        else return 1;
    }

    void EndLongForm()
    {
        longFormPanel.SetActive(false);

        if (playerMovement != null)
            playerMovement.enabled = true;

        if (feedbackManager != null)
            feedbackManager.ShowFeedback(task1Score, task2Score, taskAnswers);
        else
            Debug.LogWarning("FeedbackManager not assigned!");
    }
}