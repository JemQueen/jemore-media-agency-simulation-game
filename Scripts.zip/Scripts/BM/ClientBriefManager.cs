using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ClientBriefManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject clientBriefPanel;
    public TextMeshProUGUI briefTitleText;
    public TextMeshProUGUI briefBodyText;
    public TextMeshProUGUI pageProgressText;
    public Button nextButton;
    public Button previousButton;

    [Header("Next Stage")]
    public LongFormTaskManager longFormTaskManager;

    private int currentPage = 0;
    private TypewriterEffect typewriter;

    private string[] briefPages = new string[]
    {
        "Welcome to your first client assignment.\n" +
        "Your client is SunGlow Beverages — a new brand preparing to launch " +
        "a range of natural fruit drinks into a competitive market.\n" +
        "Read through this brief carefully before proceeding to your task.",

        "The beverage market is crowded with sugary, artificial drinks. " +
        "SunGlow believes there is a gap for something healthier and more exciting.\n" +
        "They need a brand strategy that helps them enter the market " +
        "with a clear identity and a strong first impression.",

        "SunGlow wants to target health-conscious young adults aged 18 to 28.\n" +
        "These are people who care about what they put in their bodies " +
        "but still want something that feels fun and social — " +
        "not boring or overly medicinal.",

        "SunGlow should feel energetic, fresh, and approachable.\n" +
        "Think vibrant colours, friendly language, and a tone that feels " +
        "like a friend recommending a healthy lifestyle — " +
        "not a doctor giving instructions.",

        "As the Brand Management intern, you have been asked to develop " +
        "a brand strategy for SunGlow Beverages.\n" +
        "You must address four key areas:\n" +
        "Target Audience, Brand Identity, Brand Positioning, and Brand Consistency.",

        "TO COMPLETE THIS TASK YOU MUST:\n" +
        "- Define SunGlow's target audience in detail\n" +
        "- Propose a brand identity including colours, tone, and values\n" +
        "- Write a clear positioning statement\n" +
        "- Explain how consistency will be maintained across platforms\n",
    };

    private string[] pageTitles = new string[]
    {
        "Client Brief — Introduction",
        "Client Brief — The Problem",
        "Client Brief — The Audience",
        "Client Brief — Brand Personality",
        "Client Brief — Your Task",
        "Client Brief — Task Checklist"
    };

    private float[] pageFontSizes = new float[]
    {
        44f, 48f, 46f, 50f, 45f, 42f
    };

    public void ShowClientBrief()
    {
        currentPage = 0;
        clientBriefPanel.SetActive(true);
        typewriter = briefBodyText.GetComponent<TypewriterEffect>();

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        DisplayPage(currentPage);
    }

    void DisplayPage(int index)
    {
        briefTitleText.text = pageTitles[index];
        briefBodyText.fontSize = pageFontSizes[index];
        pageProgressText.text = $"Page {index + 1} of {briefPages.Length}";

        if (typewriter != null)
            typewriter.PlayText(briefPages[index]);
        else
            briefBodyText.text = briefPages[index];

        if (index == briefPages.Length - 1)
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Accept";
        else
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Next";

        if (previousButton != null)
            previousButton.gameObject.SetActive(index > 0);
    }

    public void OnNextPressed()
    {
        currentPage++;

        if (currentPage < briefPages.Length)
            DisplayPage(currentPage);
        else
            EndBrief();
    }

    public void OnPreviousPressed()
    {
        if (currentPage > 0)
        {
            currentPage--;
            DisplayPage(currentPage);
        }
    }

    void EndBrief()
    {
        clientBriefPanel.SetActive(false);

        if (longFormTaskManager != null)
            longFormTaskManager.ShowTask();
        else
            Debug.LogWarning("LongFormTaskManager not assigned!");
    }
}