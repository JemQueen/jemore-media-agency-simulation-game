using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuizManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject quizPanel;

    [Header("UI")]
    public TextMeshProUGUI quizTitleText;
    public TextMeshProUGUI questionNumberText;
    public TextMeshProUGUI statementText;
    public TextMeshProUGUI feedbackText;
    public Button trueButton;
    public Button falseButton;

    [Header("Next Stage")]
    public DepartmentScoreManager departmentScoreManager;

    public static int quizScore = 0;

    private int currentQuestion = 0;
    private bool answered = false;

    private string[] statements = new string[]
    {
        "A target audience is the specific group of people a brand aims to reach.",
        "Brand identity includes a company's logo, colours, and tone of voice.",
        "SunGlow's target audience is adults aged 40 to 60.",
        "Brand positioning explains how a brand is different from its competitors.",
        "Coca-Cola is a famous example of strong brand consistency.",
        "Brand consistency means changing your logo and message regularly.",
        "SunGlow wants to feel energetic, fresh, and approachable.",
        "A positioning statement should be vague and hard to understand."
    };

    private bool[] correctAnswers = new bool[]
    {
        true,
        true,
        false,
        true,
        true,
        false,
        true,
        false
    };

    void Start()
    {
        if (quizPanel != null)
            quizPanel.SetActive(false);
    }

    public void StartQuiz()
    {
        currentQuestion = 0;
        quizScore = 0;
        quizPanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (feedbackText != null)
            feedbackText.gameObject.SetActive(false);

        DisplayQuestion(currentQuestion);
    }

    void DisplayQuestion(int index)
    {
        answered = false;
        feedbackText.gameObject.SetActive(false);

        trueButton.interactable = true;
        falseButton.interactable = true;

        questionNumberText.text = $"Question {index + 1} of {statements.Length}";
        statementText.text = statements[index];
    }

    public void OnTruePressed()
    {
        if (answered) return;
        CheckAnswer(true);
    }

    public void OnFalsePressed()
    {
        if (answered) return;
        CheckAnswer(false);
    }

    void CheckAnswer(bool playerAnswer)
    {
    answered = true;

    trueButton.interactable = false;
    falseButton.interactable = false;

    bool isCorrect = playerAnswer == correctAnswers[currentQuestion];

    feedbackText.gameObject.SetActive(true);

    if (isCorrect)
    {
        quizScore++;
        feedbackText.text = "Correct!";
    }
    else
    {
        feedbackText.text = "Incorrect!";
    }

    Invoke(nameof(NextQuestion), 2f);
    }

    void NextQuestion()
    {
        currentQuestion++;

        if (currentQuestion < statements.Length)
        {
            DisplayQuestion(currentQuestion);
        }
        else
        {
            EndQuiz();
        }
    }

    void EndQuiz()
    {
        quizPanel.SetActive(false);

        if (departmentScoreManager != null)
            departmentScoreManager.ShowScore();
        else
            Debug.LogWarning("DepartmentScoreManager not assigned!");
    }
}