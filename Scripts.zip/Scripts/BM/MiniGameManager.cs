using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MiniGameManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject miniGamePanel;

    [Header("UI")]
    public TextMeshProUGUI resultText;
    public Button submitButton;

    [Header("Drop Zones")]
    public DropZone fitsZone;
    public DropZone doesNotFitZone;

    [Header("Cards")]
    public DraggableCard[] allCards;

    [Header("Next Stage")]
    public QuizManager quizManager;

    public static int miniGameScore = 0;

    void Start()
    {
        if (miniGamePanel != null)
            miniGamePanel.SetActive(false);

        if (resultText != null)
            resultText.gameObject.SetActive(false);
    }

    public void StartMiniGame()
    {
        miniGamePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (resultText != null)
            resultText.gameObject.SetActive(false);

        submitButton.interactable = true;
    }

    public void OnCheckAnswers()
    {
        int correct = 0;
        int total = allCards.Length;

        foreach (DraggableCard card in allCards)
        {
            if (card.currentZone == null) continue;

            bool placedInFits = card.currentZone == fitsZone.contentContainer;

            if (card.fitsWithSunGlow == placedInFits)
                correct++;
        }

        miniGameScore = correct;

        resultText.gameObject.SetActive(true);
        resultText.text = $"You got {correct} out of {total} correct!";

        submitButton.interactable = false;

        Invoke(nameof(ProceedToQuiz), 3f);
    }

    void ProceedToQuiz()
    {
        miniGamePanel.SetActive(false);

        if (quizManager != null)
            quizManager.StartQuiz();
        else
            Debug.LogWarning("QuizManager not assigned!");
    }
}