using UnityEngine;
using TMPro;

public class DepartmentScoreManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject scorePanel;

    [Header("Score Display")]
    public TextMeshProUGUI scoreTitleText;
    public TextMeshProUGUI writtenScoreText;
    public TextMeshProUGUI miniGameScoreText;
    public TextMeshProUGUI quizScoreText;
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI summaryText;

    public static int brandTotalScore = 0;

    private BossInteract bossInteract;

    void Start()
    {
        if (scorePanel != null)
            scorePanel.SetActive(false);

        bossInteract = FindFirstObjectByType<BossInteract>();
    }

    public void ShowScore()
    {
        scorePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        int writtenTotal  = LongFormTaskManager.task1Score +
                            LongFormTaskManager.task2Score;
        int miniGameTotal = MiniGameManager.miniGameScore;
        int quizTotal     = QuizManager.quizScore;
        int total         = writtenTotal + miniGameTotal + quizTotal;

        brandTotalScore = total;

        writtenScoreText.text  = $"Written Task:        {writtenTotal} / 10";
        miniGameScoreText.text = $"Brand Sorting:      {miniGameTotal} / 6";
        quizScoreText.text     = $"Quiz:                    {quizTotal} / 8";
        totalScoreText.text    = $"Department Total:   {total} / 24";
        summaryText.text       = "Your Brand Management score has been recorded. " +
                                 "Complete all four departments to see your final " +
                                 "evaluation.";
    }

    public void OnContinuePressed()
    {
        scorePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // Re-enable player movement
        FindFirstObjectByType<PlayerMovement>().enabled = true;

        // Notify boss that Brand Management is complete
        if (bossInteract != null)
            bossInteract.OnBrandManagementComplete();
        else
            Debug.LogWarning("BossInteract not found!");
    }
}