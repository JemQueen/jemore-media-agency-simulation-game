using UnityEngine;
using TMPro;

public class LongFormFeedbackManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject feedbackPanel;

    [Header("Task 1 Results")]
    public TextMeshProUGUI task1ScoreText;
    public TextMeshProUGUI task1FeedbackText;

    [Header("Task 2 Results")]
    public TextMeshProUGUI task2ScoreText;
    public TextMeshProUGUI task2FeedbackText;

    [Header("Overall")]
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI overallFeedbackText;

    [Header("Next Stage")]
    public MiniGameManager miniGameManager;

    public static int longFormTotalScore = 0;

    void Start()
    {
        if (feedbackPanel != null)
            feedbackPanel.SetActive(false);
    }

    public void ShowFeedback(int score1, int score2, string[] answers)
    {
        feedbackPanel.SetActive(true);

        int total = score1 + score2;
        longFormTotalScore = total;

        task1ScoreText.text = $"Target Audience Profile — {score1} / 5";
        task1FeedbackText.text = GetTask1Feedback(score1);

        task2ScoreText.text = $"Positioning Statement — {score2} / 5";
        task2FeedbackText.text = GetTask2Feedback(score2);

        totalScoreText.text = $"Written Task Total:  {total} / 10";
        overallFeedbackText.text = GetOverallFeedback(total);
    }

    string GetTask1Feedback(int score)
    {
        if (score >= 5)
            return "Excellent. You clearly identified the target audience " +
                   "with strong detail around age, lifestyle and values.";
        else if (score >= 4)
            return "Good work. You covered most key audience traits. " +
                   "Consider adding more detail about their values and behaviour.";
        else if (score >= 3)
            return "You have a basic understanding of the audience. " +
                   "Try to be more specific about who they are and what drives them.";
        else
            return "Your audience profile needs more detail. " +
                   "Think about age, lifestyle, values, and why they would choose SunGlow.";
    }

    string GetTask2Feedback(int score)
    {
        if (score >= 5)
            return "Outstanding positioning statement. You clearly communicated " +
                   "the audience, the benefit, and the point of difference.";
        else if (score >= 4)
            return "Strong statement. You covered the key elements well. " +
                   "A stronger differentiator would make it even more compelling.";
        else if (score >= 3)
            return "Your statement shows understanding but lacks clarity. " +
                   "Make sure you state who it is for, what it offers, and why it is different.";
        else
            return "Your positioning statement needs development. " +
                   "A good statement is clear, specific, and highlights what makes SunGlow unique.";
    }

    string GetOverallFeedback(int total)
    {
        if (total >= 9)
            return "Outstanding written performance. You demonstrate a strong " +
                   "grasp of brand strategy thinking.";
        else if (total >= 7)
            return "Good performance overall. You understand the core concepts " +
                   "and can apply them to a real brief.";
        else if (total >= 5)
            return "Decent effort. Review the brief concepts and think about " +
                   "how each one applies to SunGlow specifically.";
        else
            return "This task was challenging but that is what learning is for. " +
                   "Revisit the tutorial concepts and consider how they apply to the brief.";
    }

    public void OnContinuePressed()
    {
    feedbackPanel.SetActive(false);

    if (miniGameManager != null)
        miniGameManager.StartMiniGame();
    else
        Debug.LogWarning("MiniGameManager not assigned!");
}
}