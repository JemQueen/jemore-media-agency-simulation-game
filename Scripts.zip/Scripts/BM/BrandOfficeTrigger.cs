using UnityEngine;

public class BrandOfficeTrigger : MonoBehaviour
{
    public TutorialManager tutorialManager;

    private bool hasTriggered = false;

    void OnTriggerEnter(Collider other)
    {
        if (hasTriggered) return;

        if (other.CompareTag("Player"))
        {
            hasTriggered = true;
            Invoke(nameof(BeginDepartment), 1.5f);
            Debug.Log("Player entered Brand Office.");
        }
    }

    void BeginDepartment()
    {
        tutorialManager.StartTutorial();
    }
}