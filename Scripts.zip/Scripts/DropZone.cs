using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DropZone : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Zone Settings")]
    public bool isFitsZone;
    public Transform contentContainer;

    [Header("Card Size in Zone")]
    public float cardScaleInZone = 0.5f;

    private Image zoneImage;
    private Color normalColor;
    private Color highlightColor = new Color(0.5f, 0.9f, 0.5f, 0.4f);

    void Start()
    {
        zoneImage = GetComponent<Image>();
        if (zoneImage != null)
            normalColor = zoneImage.color;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (zoneImage != null)
            zoneImage.color = highlightColor;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (zoneImage != null)
            zoneImage.color = normalColor;
    }

    public void OnDrop(PointerEventData eventData)
    {
        if (zoneImage != null)
            zoneImage.color = normalColor;

        // Try DraggableCard first (Brand Mini Game)
        DraggableCard card = eventData.pointerDrag?
            .GetComponent<DraggableCard>();

        if (card != null)
        {
            card.transform.SetParent(contentContainer);
            card.currentZone = contentContainer;

            RectTransform cardRect = card.GetComponent<RectTransform>();
            cardRect.localPosition = Vector3.zero;
            cardRect.localScale = new Vector3(
                cardScaleInZone, cardScaleInZone, 1f);
            return;
        }

        // Try StrategyCard (Strategy Mini Game)
        StrategyCard strategyCard = eventData.pointerDrag?
            .GetComponent<StrategyCard>();

        if (strategyCard != null)
        {
            strategyCard.transform.SetParent(contentContainer);
            strategyCard.currentZone = contentContainer;

            RectTransform cardRect = strategyCard.GetComponent<RectTransform>();
            cardRect.localPosition = Vector3.zero;
            cardRect.localScale = new Vector3(
                cardScaleInZone, cardScaleInZone, 1f);
        }
    }
}