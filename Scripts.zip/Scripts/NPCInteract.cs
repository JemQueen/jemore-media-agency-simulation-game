using UnityEngine;
using System.Collections;

public class NPCInteract : MonoBehaviour, IInteractable
{
    public string npcName = "Brand Manager";

    [TextArea(2, 5)]
    public string[] dialogueLines;

    private Animator animator;
    private DialogueManager dialogueManager;

    void Start()
    {
        animator = GetComponent<Animator>();
        dialogueManager = FindObjectOfType<DialogueManager>();
    }

    public void Interact()
    {
        StartCoroutine(TalkRoutine());
    }

    IEnumerator TalkRoutine()
    {
        if (animator != null)
        {
            animator.SetBool("IsTalking", true);
        }

        if (dialogueManager != null)
        {
            dialogueManager.StartDialogue(npcName, dialogueLines);
        }

        yield return null;
    }

    public void StopTalking()
    {
        if (animator != null)
        {
            animator.SetBool("IsTalking", false);
        }
    }
}