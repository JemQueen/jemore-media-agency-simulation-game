using UnityEngine;
using TMPro;

public class ProductionLongFormFeedbackManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject feedbackPanel;

    [Header("Task 1 Results")]
    public TextMeshProUGUI task1ScoreText;
    public TextMeshProUGUI task1FeedbackText;

    [Header("Task 2 Results")]
    public TextMeshProUGUI task2ScoreText;
    public TextMeshProUGUI task2FeedbackText;

    [Header("Overall")]
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI overallFeedbackText;

    [Header("Next Stage")]
    public ProductionMiniGameManager productionMiniGameManager;

    public static int longFormTotalScore = 0;

    void Start()
    {
        if (feedbackPanel != null)
            feedbackPanel.SetActive(false);
    }

    public void ShowFeedback(int score1, int score2, string[] answers)
    {
        feedbackPanel.SetActive(true);

        int total = score1 + score2;
        longFormTotalScore = total;

        task1ScoreText.text = $"Production Plan — {score1} / 5";
        task1FeedbackText.text = GetTask1Feedback(score1);

        task2ScoreText.text = $"Budget and Timeline — {score2} / 5";
        task2FeedbackText.text = GetTask2Feedback(score2);

        totalScoreText.text = $"Written Task Total:  {total} / 10";
        overallFeedbackText.text = GetOverallFeedback(total);
    }

    string GetTask1Feedback(int score)
    {
        if (score >= 5)
            return "Excellent production plan. You clearly outlined all " +
                   "three phases and showed strong understanding of what " +
                   "each stage involves.";
        else if (score >= 4)
            return "Good plan. You covered most production phases well. " +
                   "Adding more detail on post-production delivery would " +
                   "strengthen it.";
        else if (score >= 3)
            return "Decent effort. Make sure you address all three phases — " +
                   "pre-production, production, and post-production — " +
                   "with specific tasks for each.";
        else
            return "Your production plan needs more detail. Think about " +
                   "everything from scripting and location scouting to " +
                   "editing and final delivery.";
    }

    string GetTask2Feedback(int score)
    {
        if (score >= 5)
            return "Outstanding budget and timeline proposal. You showed " +
                   "clear financial thinking and realistic milestone planning.";
        else if (score >= 4)
            return "Strong proposal. Your budget breakdown and timeline " +
                   "are logical. Consider adding contingency planning.";
        else if (score >= 3)
            return "Your proposal shows some planning awareness. Be more " +
                   "specific about how you would divide the budget and " +
                   "set weekly milestones.";
        else
            return "Budget and timeline management requires specific numbers " +
                   "and clear deadlines. Revisit the brief and think about " +
                   "costs and weekly targets.";
    }

    string GetOverallFeedback(int total)
    {
        if (total >= 9)
            return "Outstanding written performance in Production. " +
                   "You think like a production professional.";
        else if (total >= 7)
            return "Good performance. You have a strong grasp of production " +
                   "planning and can apply it to real campaigns.";
        else if (total >= 5)
            return "Decent effort. Keep building your understanding of " +
                   "production phases and financial planning.";
        else
            return "Production challenged you — review the three production " +
                   "phases and think about how they apply to SunGlow.";
    }

    public void OnContinuePressed()
    {
        feedbackPanel.SetActive(false);

        if (productionMiniGameManager != null)
            productionMiniGameManager.StartMiniGame();
        else
            Debug.LogWarning("ProductionMiniGameManager not assigned!");
    }
}