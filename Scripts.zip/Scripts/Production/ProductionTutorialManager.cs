using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class ProductionTutorialManager : MonoBehaviour
{
    [Header("Concept Data")]
    public ConceptData[] concepts;

    [Header("Intro Panel")]
    public GameObject introPanel;
    public TextMeshProUGUI introTitleText;
    public TextMeshProUGUI introBodyText;
    public TextMeshProUGUI introNoteText;

    [Header("Tutorial Panel")]
    public GameObject tutorialPanel;
    public TextMeshProUGUI conceptTitleText;
    public TextMeshProUGUI conceptBodyText;
    public TextMeshProUGUI exampleText;
    public TextMeshProUGUI progressText;
    public Button nextButton;

    [Header("Next Stage")]
    public ProductionClientBriefManager productionClientBriefManager;

    private int currentIndex = 0;

    void Start()
    {
        if (introPanel != null)
            introPanel.SetActive(false);

        if (tutorialPanel != null)
            tutorialPanel.SetActive(false);
    }

    public void StartTutorial()
    {
        currentIndex = 0;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        FindAnyObjectByType<CameraFollow>()?.SetCanLook(false);

        ShowIntroPanel();
    }

    void ShowIntroPanel()
    {
        introPanel.SetActive(true);
        tutorialPanel.SetActive(false);

        // Keep the title display snappy and instant
        introTitleText.text = "Welcome to the Production Department";

        // Prevent visual glitching by ensuring old text is wiped
        introBodyText.text = "";
        introNoteText.text = "";

        // Trigger sequential typewriter typing sequence
        StartCoroutine(TypeIntroSequentially());
    }

    IEnumerator TypeIntroSequentially()
    {
    
        TypewriterEffect bodyTypewriter = introBodyText.GetComponent<TypewriterEffect>();
        string bodyContent = "The Production department is where all the creative work " +
                             "comes to life. Production professionals manage the entire " +
                             "process of creating campaign content — from the first planning " +
                             "meeting to the final delivered asset.\n\n" +
                             "In this department, your supervisor will walk you through four " +
                             "essential production concepts that every Production professional " +
                             "must understand before managing a real campaign.";

        if (bodyTypewriter != null)
        {
            bodyTypewriter.PlayText(bodyContent);
            yield return new WaitUntil(() => !bodyTypewriter.IsTyping());
        }
        else
        {
            introBodyText.text = bodyContent;
        }

        // Brief cinematic beat
        yield return new WaitForSeconds(0.4f);

        TypewriterEffect noteTypewriter = introNoteText.GetComponent<TypewriterEffect>();
        string noteContent = "Pay close attention — these concepts will appear in your " +
                             "client brief, written task, mini game, and final quiz.";

        if (noteTypewriter != null)
        {
            noteTypewriter.PlayText(noteContent);
        }
        else
        {
            introNoteText.text = noteContent;
        }
    }

    public void OnBeginPressed()
    {
        StopAllCoroutines();

        introPanel.SetActive(false);
        tutorialPanel.SetActive(true);
        DisplayConcept(0);
    }

    void DisplayConcept(int index)
    {
        ConceptData concept = concepts[index];
        conceptTitleText.text = concept.conceptTitle;
        progressText.text = $"Concept {index + 1} of {concepts.Length}";
        exampleText.text = "";

        if (index == concepts.Length - 1)
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Proceed";
        else
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Next";

        StartCoroutine(TypeConceptSequentially(concept));
    }

    IEnumerator TypeConceptSequentially(ConceptData concept)
    {
        TypewriterEffect bodyTypewriter = conceptBodyText.GetComponent<TypewriterEffect>();

        if (bodyTypewriter != null)
        {
            bodyTypewriter.PlayText(concept.conceptExplanation);
            yield return new WaitUntil(() => !bodyTypewriter.IsTyping());
        }
        else
        {
            conceptBodyText.text = concept.conceptExplanation;
        }

        yield return new WaitForSeconds(0.4f);

        TypewriterEffect exampleTypewriter = exampleText.GetComponent<TypewriterEffect>();

        if (exampleTypewriter != null)
            exampleTypewriter.PlayText("Example:\n" + concept.realWorldExample);
        else
            exampleText.text = "Example:\n" + concept.realWorldExample;
    }

    public void OnNextButtonPressed()
    {
        currentIndex++;

        if (currentIndex < concepts.Length)
            DisplayConcept(currentIndex);
        else
            EndTutorial();
    }

    void EndTutorial()
    {
        tutorialPanel.SetActive(false);

        if (productionClientBriefManager != null)
            productionClientBriefManager.ShowClientBrief();
        else
            Debug.LogWarning("ProductionClientBriefManager not assigned!");
    }
}