using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public enum ProductionPhase
{
    PreProduction,
    Production,
    PostProduction
}

public class TimelineCard : MonoBehaviour,
    IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [Header("Card Data")]
    public string cardLabel;
    public ProductionPhase correctPhase;

    [Header("UI")]
    public TextMeshProUGUI cardText;

    private Canvas canvas;
    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;

    private Vector3 originalPosition;
    private Transform originalParent;
    private Vector3 originalScale;

    public Transform currentZone = null;

    void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();
        canvas = GetComponentInParent<Canvas>();

        if (canvasGroup == null)
            canvasGroup = gameObject.AddComponent<CanvasGroup>();
    }

    void Start()
    {
        originalPosition = rectTransform.localPosition;
        originalParent = transform.parent;
        originalScale = transform.localScale;

        if (cardText != null)
            cardText.text = cardLabel;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        originalPosition = rectTransform.localPosition;
        originalParent = transform.parent;

        transform.SetParent(canvas.transform);
        transform.localScale = originalScale;

        canvasGroup.blocksRaycasts = false;
        canvasGroup.alpha = 0.8f;
    }

    public void OnDrag(PointerEventData eventData)
    {
        rectTransform.anchoredPosition +=
            eventData.delta / canvas.scaleFactor;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        canvasGroup.blocksRaycasts = true;
        canvasGroup.alpha = 1f;

        if (currentZone == null)
        {
            transform.SetParent(originalParent);
            rectTransform.localPosition = originalPosition;
            transform.localScale = originalScale;
        }
    }
}