using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ProductionQuizManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject quizPanel;

    [Header("UI")]
    public TextMeshProUGUI quizTitleText;
    public TextMeshProUGUI questionNumberText;
    public TextMeshProUGUI statementText;
    public TextMeshProUGUI feedbackText;
    public Button trueButton;
    public Button falseButton;

    [Header("Next Stage")]
    public ProductionScoreManager productionScoreManager;

    public static int quizScore = 0;

    private int currentQuestion = 0;
    private bool answered = false;

    private string[] statements = new string[]
    {
        "Pre-production includes scripting, casting, and location scouting.",
        "Colour grading happens during the production shoot.",
        "Post-production involves editing, sound design, and final delivery.",
        "Budget management means tracking costs to avoid overspending.",
        "A timeline helps ensure the campaign is delivered on time.",
        "Filming the advertisement is part of the post-production phase.",
        "A production schedule assigns tasks and deadlines to the team.",
        "Pre-production planning has no impact on the quality of the final product."
    };

    private bool[] correctAnswers = new bool[]
    {
        true,
        false,
        true,
        true,
        true,
        false,
        true,
        false
    };

    void Start()
    {
        if (quizPanel != null)
            quizPanel.SetActive(false);
    }

    public void StartQuiz()
    {
        currentQuestion = 0;
        quizScore = 0;
        quizPanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (feedbackText != null)
            feedbackText.gameObject.SetActive(false);

        DisplayQuestion(currentQuestion);
    }

    void DisplayQuestion(int index)
    {
        answered = false;
        feedbackText.gameObject.SetActive(false);

        trueButton.interactable = true;
        falseButton.interactable = true;

        questionNumberText.text = $"Question {index + 1} of {statements.Length}";
        statementText.text = statements[index];
    }

    public void OnTruePressed()
    {
        if (answered) return;
        CheckAnswer(true);
    }

    public void OnFalsePressed()
    {
        if (answered) return;
        CheckAnswer(false);
    }

    void CheckAnswer(bool playerAnswer)
    {
        answered = true;

        trueButton.interactable = false;
        falseButton.interactable = false;

        bool isCorrect = playerAnswer == correctAnswers[currentQuestion];

        feedbackText.gameObject.SetActive(true);

        if (isCorrect)
        {
            quizScore++;
            feedbackText.text = "Correct!";
         }
        else
        {
            feedbackText.text = "Incorrect!";
        }

        Invoke(nameof(NextQuestion), 2f);
    }

    void NextQuestion()
    {
        currentQuestion++;

        if (currentQuestion < statements.Length)
            DisplayQuestion(currentQuestion);
        else
            EndQuiz();
    }

    void EndQuiz()
    {
        quizPanel.SetActive(false);

        if (productionScoreManager != null)
            productionScoreManager.ShowScore();
        else
            Debug.LogWarning("ProductionScoreManager not assigned!");
    }
}