using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ProductionMiniGameManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject miniGamePanel;

    [Header("UI")]
    public TextMeshProUGUI resultText;
    public Button submitButton;

    [Header("Drop Zones — drag the Zone GameObject")]
    public TimelineDropZone preProductionZone;
    public TimelineDropZone productionZone;
    public TimelineDropZone postProductionZone;

    [Header("Cards")]
    public TimelineCard[] allCards;

    [Header("Next Stage")]
    public ProductionQuizManager productionQuizManager;

    public static int miniGameScore = 0;

    void Start()
    {
        if (miniGamePanel != null)
            miniGamePanel.SetActive(false);

        if (resultText != null)
            resultText.gameObject.SetActive(false);
    }

    public void StartMiniGame()
    {
        miniGamePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (resultText != null)
            resultText.gameObject.SetActive(false);

        submitButton.interactable = true;
    }

    public void OnCheckTimeline()
    {
        int correct = 0;

        foreach (TimelineCard card in allCards)
        {
            if (card.currentZone == null)
            {
                Debug.Log($"{card.cardLabel} — not placed");
                continue;
            }

            bool isCorrect = false;

            if (card.correctPhase == ProductionPhase.PreProduction &&
                card.currentZone == preProductionZone.contentContainer)
                isCorrect = true;
            else if (card.correctPhase == ProductionPhase.Production &&
                card.currentZone == productionZone.contentContainer)
                isCorrect = true;
            else if (card.correctPhase == ProductionPhase.PostProduction &&
                card.currentZone == postProductionZone.contentContainer)
                isCorrect = true;

            Debug.Log($"{card.cardLabel} | " +
                      $"currentZone: {card.currentZone?.name} | " +
                      $"correct: {isCorrect}");

            if (isCorrect) correct++;
        }

        miniGameScore = correct;

        resultText.gameObject.SetActive(true);
        resultText.text =
            $"You placed {correct} out of {allCards.Length} tasks correctly!";

        submitButton.interactable = false;
        Invoke(nameof(ProceedToQuiz), 3f);
    }

    void ProceedToQuiz()
    {
        miniGamePanel.SetActive(false);

        if (productionQuizManager != null)
            productionQuizManager.StartQuiz();
        else
            Debug.LogWarning("ProductionQuizManager not assigned!");
    }
}