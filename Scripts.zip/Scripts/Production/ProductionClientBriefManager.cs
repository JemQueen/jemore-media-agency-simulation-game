using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ProductionClientBriefManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject clientBriefPanel;
    public TextMeshProUGUI briefTitleText;
    public TextMeshProUGUI briefBodyText;
    public TextMeshProUGUI pageProgressText;
    public Button nextButton;
    public Button previousButton;

    [Header("Next Stage")]
    public ProductionLongFormManager productionLongFormManager;

    private int currentPage = 0;
    private TypewriterEffect typewriter;

    private string[] briefPages = new string[]
    {
        // page 1
        "The Brand, Strategy, and Art teams have completed their work " +
        "on the SunGlow Beverages campaign.\n" +
        "Now it is the Production department's job to bring everything " +
        "to life and deliver the final campaign assets.",

        // page 2
        "THE CAMPAIGN OVERVIEW:\n" +
        "SunGlow needs a 30-second video advertisement and a set of " +
        "social media images for their launch campaign.\n" +
        "The content must feel energetic, natural, and fun — " +
        "matching the brand identity the Art team created.",

        // page 3
        "THE TIMELINE:\n" +
        "SunGlow has a hard launch deadline of 8 weeks from today.\n" +
        "The production team must complete pre-production, filming, " +
        "and post-production within this window to deliver on time.",

        // page 4
        "THE BUDGET:\n" +
        "The total production budget is 50,000 pounds.\n" +
        "This must cover talent, location hire, equipment, crew, " +
        "editing, and any additional post-production costs.\n" +
        "Careful budget management is essential.",

        // page 5
        "YOUR PRODUCTION TASK:\n" +
        "As the Production intern you must plan the full production " +
        "process for the SunGlow campaign.\n" +
        "You will need to think about pre-production planning, " +
        "the production shoot, and post-production delivery.",

        // page 6
        "TO COMPLETE THIS TASK YOU MUST:\n" +
        "- Outline your pre-production plan\n" +
        "- Describe what happens during the production shoot\n" +
        "- Explain the post-production process\n" +
        "- Show how you will manage the budget and timeline\n" +
        "- Ensure the final product matches the SunGlow brand"
    };

    private string[] pageTitles = new string[]
    {
        "Production Brief — Overview",
        "Production Brief — The Campaign",
        "Production Brief — The Timeline",
        "Production Brief — The Budget",
        "Production Brief — Your Task",
        "Production Brief — Task Checklist"
    };

    private float[] pageFontSizes = new float[]
    {
        46f, 40f, 46f, 40f, 43f, 40f
    };

    public void ShowClientBrief()
    {
        currentPage = 0;
        clientBriefPanel.SetActive(true);
        typewriter = briefBodyText.GetComponent<TypewriterEffect>();

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        DisplayPage(currentPage);
    }

    void DisplayPage(int index)
    {
        briefTitleText.text = pageTitles[index];
        briefBodyText.fontSize = pageFontSizes[index];
        pageProgressText.text = $"Page {index + 1} of {briefPages.Length}";

        if (typewriter != null)
            typewriter.PlayText(briefPages[index]);
        else
            briefBodyText.text = briefPages[index];

        if (index == briefPages.Length - 1)
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Accept";
        else
            nextButton.GetComponentInChildren<TextMeshProUGUI>().text = "Next";

        if (previousButton != null)
            previousButton.gameObject.SetActive(index > 0);
    }

    public void OnNextPressed()
    {
        currentPage++;

        if (currentPage < briefPages.Length)
            DisplayPage(currentPage);
        else
            EndBrief();
    }

    public void OnPreviousPressed()
    {
        if (currentPage > 0)
        {
            currentPage--;
            DisplayPage(currentPage);
        }
    }

    void EndBrief()
    {
        clientBriefPanel.SetActive(false);

        if (productionLongFormManager != null)
            productionLongFormManager.ShowTask();
        else
            Debug.LogWarning("ProductionLongFormManager not assigned!");
    }
}