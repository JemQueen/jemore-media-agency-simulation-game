using UnityEngine;
using TMPro;

public class ProductionScoreManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject scorePanel;

    [Header("Score Display")]
    public TextMeshProUGUI scoreTitleText;
    public TextMeshProUGUI writtenScoreText;
    public TextMeshProUGUI miniGameScoreText;
    public TextMeshProUGUI quizScoreText;
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI summaryText;

    public static int productionTotalScore = 0;

    void Start()
    {
        if (scorePanel != null)
            scorePanel.SetActive(false);
    }

    public void ShowScore()
    {
        scorePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        int writtenTotal  = ProductionLongFormManager.task1Score +
                            ProductionLongFormManager.task2Score;
        int miniGameTotal = ProductionMiniGameManager.miniGameScore;
        int quizTotal     = ProductionQuizManager.quizScore;
        int total         = writtenTotal + miniGameTotal + quizTotal;

        productionTotalScore = total;

        writtenScoreText.text  = $"Written Task:       {writtenTotal} / 10";
        miniGameScoreText.text = $"Timeline Sorter:    {miniGameTotal} / 6";
        quizScoreText.text     = $"Quiz:               {quizTotal} / 8";
        totalScoreText.text    = $"Department Total:   {total} / 24";
        summaryText.text       =
            "Congratulations! You have completed all four departments.\n" +
            "Your scores have been recorded. Proceed to your " +
            "final evaluation to see your recommended career path.";
    }

    public void OnContinuePressed()
    {
        scorePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        FindFirstObjectByType<PlayerMovement>().enabled = true;

        // Load final evaluation
        FinalEvaluationManager finalEval =
            FindFirstObjectByType<FinalEvaluationManager>();

        if (finalEval != null)
            finalEval.ShowFinalEvaluation();
        else
            Debug.LogWarning("FinalEvaluationManager not assigned!");
    }
}