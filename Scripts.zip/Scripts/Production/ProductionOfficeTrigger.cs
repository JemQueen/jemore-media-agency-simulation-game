using UnityEngine;

public class ProductionOfficeTrigger : MonoBehaviour
{
    public ProductionTutorialManager productionTutorialManager;

    private bool hasTriggered = false;

    void Start()
    {
        gameObject.SetActive(false);
    }

    void OnTriggerEnter(Collider other)
    {
        if (hasTriggered) return;

        if (other.CompareTag("Player"))
        {
            hasTriggered = true;
            Invoke(nameof(BeginDepartment), 1.5f);
            Debug.Log("Player entered Production Office.");
        }
    }

    void BeginDepartment()
    {
        if (productionTutorialManager != null)
            productionTutorialManager.StartTutorial();
        else
            Debug.LogWarning("ProductionTutorialManager not assigned!");
    }
}