using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class ProductionLongFormManager : MonoBehaviour
{
    [Header("Panel")]
    public GameObject longFormPanel;

    [Header("Task Display")]
    public TextMeshProUGUI taskBadgeText;
    public TextMeshProUGUI taskTitleText;
    public TextMeshProUGUI instructionText;
    public TextMeshProUGUI hintText;

    [Header("Input")]
    public TMP_InputField answerInputField;

    [Header("Button")]
    public Button submitButton;

    [Header("Next Stage")]
    public ProductionLongFormFeedbackManager feedbackManager;

    public static int task1Score = 0;
    public static int task2Score = 0;

    private int currentTask = 0;
    private string[] taskAnswers = new string[2];
    private PlayerMovement playerMovement;

    private string[] taskBadges = new string[]
    {
        "TASK  01 OF 02",
        "TASK  02 OF 02"
    };

    private string[] taskTitles = new string[]
    {
        "Production Plan",
        "Budget and Timeline Proposal"
    };

    private string[] taskInstructions = new string[]
    {
        "Outline the full production plan for the SunGlow campaign.\n" +
        "Describe what you would do in pre-production, during the " +
        "production shoot, and in post-production.",

        "Propose a budget and timeline for the SunGlow campaign.\n" +
        "Explain how you would divide the 50,000 pound budget across " +
        "the production phases and how you would ensure delivery " +
        "within 8 weeks."
    };

    private string[] taskHints = new string[]
    {
        "Think about: planning, filming, editing, " +
        "and final delivery.",
        "Think about: talent costs, equipment, crew," +
        "and contingency planning."
    };

    private string[][] taskKeywords = new string[][]
    {
        new string[] { "pre-production", "production", "post-production",
                       "script", "location", "filming", "editing",
                       "schedule", "shoot", "delivery" },

  
        new string[] { "budget", "timeline", "cost", "week", "milestone",
                       "talent", "equipment", "editing", "contingency",
                       "deadline" }
    };

    void Start()
    {
        if (longFormPanel != null)
            longFormPanel.SetActive(false);

        playerMovement = FindFirstObjectByType<PlayerMovement>();
    }

    public void ShowTask()
    {
        currentTask = 0;
        longFormPanel.SetActive(true);

        if (playerMovement != null)
            playerMovement.enabled = false;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        DisplayTask(currentTask);
    }

    void DisplayTask(int index)
    {
        taskBadgeText.text = taskBadges[index];
        taskTitleText.text = taskTitles[index];
        instructionText.text = taskInstructions[index];
        hintText.text = "Hint: " + taskHints[index];
        answerInputField.text = "";
        answerInputField.textComponent.color = Color.black;

        if (index == taskTitles.Length - 1)
            submitButton.GetComponentInChildren<TextMeshProUGUI>().text =
                "Submit";
        else
            submitButton.GetComponentInChildren<TextMeshProUGUI>().text =
                "Submit";

        StartCoroutine(FocusInputField());
    }

    IEnumerator FocusInputField()
    {
        yield return null;
        yield return null;
        answerInputField.interactable = true;
        answerInputField.ActivateInputField();
    }

    public void OnSubmitPressed()
    {
        string answer = answerInputField.text.Trim();

        if (answer.Length < 20)
        {
            hintText.text =
                "Please write a more detailed response before submitting.";
            return;
        }

        taskAnswers[currentTask] = answer;

        int score = ScoreAnswer(answer, taskKeywords[currentTask]);

        if (currentTask == 0)
            task1Score = score;
        else
            task2Score = score;

        currentTask++;

        if (currentTask < taskTitles.Length)
            DisplayTask(currentTask);
        else
            EndLongForm();
    }

    int ScoreAnswer(string answer, string[] keywords)
    {
        string lowerAnswer = answer.ToLower();
        int score = 0;

        foreach (string keyword in keywords)
        {
            if (lowerAnswer.Contains(keyword.ToLower()))
                score++;
        }

        float ratio = (float)score / keywords.Length;

        if (ratio >= 0.7f) return 5;
        else if (ratio >= 0.5f) return 4;
        else if (ratio >= 0.3f) return 3;
        else if (ratio >= 0.15f) return 2;
        else return 1;
    }

    void EndLongForm()
    {
        longFormPanel.SetActive(false);

        if (playerMovement != null)
            playerMovement.enabled = true;

        if (feedbackManager != null)
            feedbackManager.ShowFeedback(task1Score, task2Score, taskAnswers);
        else
            Debug.LogWarning("ProductionLongFormFeedbackManager not assigned!");
    }
}