using UnityEngine;
using System.Collections;

public class BossInteract : MonoBehaviour, IInteractable
{
    public string npcName = "Supervisor";

    [Header("First Dialogue — Brand Management Intro")]
    [TextArea(2, 5)]
    public string[] dialogueLines;
    public float[] dialogueFontSizes = new float[]
    {
        20f, 20f, 20f, 20f, 20f
    };

    [Header("Second Dialogue — After Brand Management")]
    [TextArea(2, 5)]
    public string[] postBrandDialogueLines;
    public float[] postBrandFontSizes = new float[]
    {
        20f, 20f, 20f, 20f, 20f
    };

    [Header("Third Dialogue — After Strategy")]
    [TextArea(2, 5)]
    public string[] postStrategyDialogueLines;
    public float[] postStrategyFontSizes = new float[]
    {
        20f, 20f, 20f, 20f, 20f
    };

    [Header("Fourth Dialogue — After Art")]
    [TextArea(2, 5)]
    public string[] postArtDialogueLines;
    public float[] postArtFontSizes = new float[]
    {
        20f, 20f, 20f, 20f, 20f
    };

    [Header("Brand Management Journey")]
    public Transform bossExitPoint;
    public Transform hallwayPoint;
    public Transform brandDoorPoint;
    public Transform brandOfficePoint;

    [Header("Strategy Department Journey")]
    public Transform BrandManagementExitPoint;
    public Transform strategyExitPoint;
    public Transform strategyHallwayPoint;
    public Transform strategyDoorPoint;
    public Transform strategyOfficePoint;

    [Header("Art Department Journey")]
    public Transform StrategyExitPoint;
    public Transform artExitPoint;
    public Transform artHallwayPoint;
    public Transform artDoorPoint;
    public Transform artOfficePoint;

    [Header("Production Department Journey")]
    public Transform artToProductionExitPoint;
    public Transform productionHallwayPoint;
    public Transform productionDoorPoint;
    public Transform productionOfficePoint;

    [Header("Brand Management UI")]
    public GameObject brandOfficeCheckpoint;
    public GameObject followBossText;

    [Header("Strategy Department UI")]
    public GameObject strategyOfficeCheckpoint;
    public GameObject followToStrategyText;

    [Header("After Brand — Return to Boss UI")]
    public GameObject talkToSupervisorText;
    public GameObject bossCheckpointAfterBrand;

    [Header("After Strategy — Return to Boss UI")]
    public GameObject talkToSupervisorAfterStrategyText;
    public GameObject bossCheckpointAfterStrategy;

    [Header("Art Department UI")]
    public GameObject artOfficeCheckpoint;
    public GameObject followToArtText;

    [Header("After Art — Return to Boss UI")]
    public GameObject talkToSupervisorAfterArtText;
    public GameObject bossCheckpointAfterArt;

    [Header("Production Department UI")]
    public GameObject productionOfficeCheckpoint;
    public GameObject followToProductionText;

    [Header("Office Triggers")]
    public StrategyOfficeTrigger strategyOfficeTrigger;
    public ArtOfficeTrigger artOfficeTrigger;
    public ProductionOfficeTrigger productionOfficeTrigger;

    public float moveSpeed = 2f;
    public float rotationSpeed = 5f;
    public float stoppingDistance = 0.3f;

    private Animator animator;
    private DialogueManager dialogueManager;
    private PlayerInteraction playerInteraction;

    private bool hasTalked = false;
    private bool hasCompletedBrand = false;
    private bool hasCompletedStrategy = false;
    private bool hasCompletedArt = false;

    void Start()
    {
        animator = GetComponent<Animator>();
        dialogueManager = FindAnyObjectByType<DialogueManager>();
        playerInteraction = FindAnyObjectByType<PlayerInteraction>();

        if (brandOfficeCheckpoint != null)
            brandOfficeCheckpoint.SetActive(false);
        if (followBossText != null)
            followBossText.SetActive(false);
        if (strategyOfficeCheckpoint != null)
            strategyOfficeCheckpoint.SetActive(false);
        if (talkToSupervisorText != null)
            talkToSupervisorText.SetActive(false);
        if (bossCheckpointAfterBrand != null)
            bossCheckpointAfterBrand.SetActive(false);
        if (followToStrategyText != null)
            followToStrategyText.SetActive(false);
        if (talkToSupervisorAfterStrategyText != null)
            talkToSupervisorAfterStrategyText.SetActive(false);
        if (bossCheckpointAfterStrategy != null)
            bossCheckpointAfterStrategy.SetActive(false);
        if (artOfficeCheckpoint != null)
            artOfficeCheckpoint.SetActive(false);
        if (followToArtText != null)
            followToArtText.SetActive(false);
        if (talkToSupervisorAfterArtText != null)
            talkToSupervisorAfterArtText.SetActive(false);
        if (bossCheckpointAfterArt != null)
            bossCheckpointAfterArt.SetActive(false);
        if (productionOfficeCheckpoint != null)
            productionOfficeCheckpoint.SetActive(false);
        if (followToProductionText != null)
            followToProductionText.SetActive(false);
    }


    public bool IsReadyToInteract()
    {
        return !hasTalked;
    }



    public void OnBrandManagementComplete()
    {
        hasCompletedBrand = true;
        hasTalked = false;

        if (playerInteraction != null)
            playerInteraction.enabled = true;

        if (talkToSupervisorText != null)
            talkToSupervisorText.SetActive(true);

        if (bossCheckpointAfterBrand != null)
            bossCheckpointAfterBrand.SetActive(true);
    }

    public void OnStrategyManagementComplete()
    {
        hasCompletedStrategy = true;
        hasTalked = false;

        if (playerInteraction != null)
            playerInteraction.enabled = true;

        if (talkToSupervisorAfterStrategyText != null)
            talkToSupervisorAfterStrategyText.SetActive(true);

        if (bossCheckpointAfterStrategy != null)
            bossCheckpointAfterStrategy.SetActive(true);

        Debug.Log("Strategy complete — boss ready for Art dialogue");
    }

    public void OnArtManagementComplete()
    {
        hasCompletedArt = true;
        hasTalked = false;

        if (playerInteraction != null)
            playerInteraction.enabled = true;

        if (talkToSupervisorAfterArtText != null)
            talkToSupervisorAfterArtText.SetActive(true);

        if (bossCheckpointAfterArt != null)
            bossCheckpointAfterArt.SetActive(true);

        Debug.Log("Art complete — boss ready for Production dialogue");
    }


    public void Interact()
    {
        if (hasTalked) return;

        hasTalked = true;

        if (talkToSupervisorText != null)
            talkToSupervisorText.SetActive(false);
        if (bossCheckpointAfterBrand != null)
            bossCheckpointAfterBrand.SetActive(false);
        if (talkToSupervisorAfterStrategyText != null)
            talkToSupervisorAfterStrategyText.SetActive(false);
        if (bossCheckpointAfterStrategy != null)
            bossCheckpointAfterStrategy.SetActive(false);
        if (talkToSupervisorAfterArtText != null)
            talkToSupervisorAfterArtText.SetActive(false);
        if (bossCheckpointAfterArt != null)
            bossCheckpointAfterArt.SetActive(false);

        if (playerInteraction != null)
            playerInteraction.enabled = false;

        if (animator != null)
            animator.SetBool("IsTalking", true);

        // Check most completed state first
        if (hasCompletedArt)
        {
            dialogueManager.onDialogueEnd = OnPostArtDialogueEnded;
            dialogueManager.StartDialogue(npcName, postArtDialogueLines,
                postArtFontSizes);
        }
        else if (hasCompletedStrategy)
        {
            dialogueManager.onDialogueEnd = OnPostStrategyDialogueEnded;
            dialogueManager.StartDialogue(npcName, postStrategyDialogueLines,
                postStrategyFontSizes);
        }
        else if (hasCompletedBrand)
        {
            dialogueManager.onDialogueEnd = OnPostBrandDialogueEnded;
            dialogueManager.StartDialogue(npcName, postBrandDialogueLines,
                postBrandFontSizes);
        }
        else
        {
            dialogueManager.onDialogueEnd = OnBossDialogueEnded;
            dialogueManager.StartDialogue(npcName, dialogueLines,
                dialogueFontSizes);
        }
    }


    void OnBossDialogueEnded()
    {
        if (brandOfficeCheckpoint != null)
            brandOfficeCheckpoint.SetActive(true);

        if (followBossText != null)
            followBossText.SetActive(true);

        if (strategyOfficeTrigger != null)
            strategyOfficeTrigger.gameObject.SetActive(false);

        StartCoroutine(BrandJourney());
    }

    IEnumerator BrandJourney()
    {
        if (animator != null)
        {
            animator.SetBool("IsTalking", false);
            animator.SetBool("IsWalking", true);
        }

        yield return MoveToPoint(bossExitPoint);
        yield return MoveToPoint(hallwayPoint);
        yield return MoveToPoint(brandDoorPoint);
        yield return MoveToPoint(brandOfficePoint);

        if (animator != null)
            animator.SetBool("IsWalking", false);
    }


    void OnPostBrandDialogueEnded()
    {
        if (strategyOfficeCheckpoint != null)
            strategyOfficeCheckpoint.SetActive(true);

        if (followToStrategyText != null)
            followToStrategyText.SetActive(true);

        if (strategyOfficeTrigger != null)
        {
            strategyOfficeTrigger.gameObject.SetActive(true);
            Debug.Log("Strategy trigger enabled");
        }
        else
            Debug.LogWarning("strategyOfficeTrigger is NULL");

        StartCoroutine(StrategyJourney());
    }

    IEnumerator StrategyJourney()
    {
        if (animator != null)
        {
            animator.SetBool("IsTalking", false);
            animator.SetBool("IsWalking", true);
        }

        yield return MoveToPoint(BrandManagementExitPoint);
        yield return MoveToPoint(strategyExitPoint);
        yield return MoveToPoint(strategyHallwayPoint);
        yield return MoveToPoint(strategyDoorPoint);
        yield return MoveToPoint(strategyOfficePoint);

        if (animator != null)
            animator.SetBool("IsWalking", false);
    }



    void OnPostStrategyDialogueEnded()
    {
        if (artOfficeCheckpoint != null)
            artOfficeCheckpoint.SetActive(true);

        if (followToArtText != null)
            followToArtText.SetActive(true);

        if (artOfficeTrigger != null)
        {
            artOfficeTrigger.gameObject.SetActive(true);
            Debug.Log("Art trigger enabled");
        }
        else
            Debug.LogWarning("artOfficeTrigger is NULL");

        StartCoroutine(ArtJourney());
    }

    IEnumerator ArtJourney()
    {
        if (animator != null)
        {
            animator.SetBool("IsTalking", false);
            animator.SetBool("IsWalking", true);
        }

        yield return MoveToPoint(StrategyExitPoint);
        yield return MoveToPoint(artExitPoint);
        yield return MoveToPoint(artHallwayPoint);
        yield return MoveToPoint(artDoorPoint);
        yield return MoveToPoint(artOfficePoint);

        if (animator != null)
            animator.SetBool("IsWalking", false);
    }


    void OnPostArtDialogueEnded()
    {
        if (productionOfficeCheckpoint != null)
            productionOfficeCheckpoint.SetActive(true);

        if (followToProductionText != null)
            followToProductionText.SetActive(true);

        if (productionOfficeTrigger != null)
        {
            productionOfficeTrigger.gameObject.SetActive(true);
            Debug.Log("Production trigger enabled");
        }
        else
            Debug.LogWarning("productionOfficeTrigger is NULL");

        StartCoroutine(ProductionJourney());
    }

    IEnumerator ProductionJourney()
    {
        if (animator != null)
        {
            animator.SetBool("IsTalking", false);
            animator.SetBool("IsWalking", true);
        }

        yield return MoveToPoint(artToProductionExitPoint);
        yield return MoveToPoint(productionHallwayPoint);
        yield return MoveToPoint(productionDoorPoint);
        yield return MoveToPoint(productionOfficePoint);

        if (animator != null)
            animator.SetBool("IsWalking", false);
    }


    IEnumerator MoveToPoint(Transform targetPoint)
    {
        if (targetPoint == null)
        {
            Debug.LogWarning("A target point is missing!");
            yield break;
        }

        while (FlatDistance(transform.position, targetPoint.position) >
            stoppingDistance)
        {
            Vector3 targetPosition = new Vector3(
                targetPoint.position.x,
                transform.position.y,
                targetPoint.position.z
            );

            Vector3 direction = (targetPosition - transform.position).normalized;

            if (direction != Vector3.zero)
            {
                Quaternion lookRotation = Quaternion.LookRotation(direction);
                transform.rotation = Quaternion.Slerp(
                    transform.rotation,
                    lookRotation,
                    rotationSpeed * Time.deltaTime
                );
            }

            transform.position = Vector3.MoveTowards(
                transform.position,
                targetPosition,
                moveSpeed * Time.deltaTime
            );

            yield return null;
        }
    }

    float FlatDistance(Vector3 a, Vector3 b)
    {
        a.y = 0;
        b.y = 0;
        return Vector3.Distance(a, b);
    }
}