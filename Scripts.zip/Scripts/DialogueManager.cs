using UnityEngine;
using TMPro;
using System;

public class DialogueManager : MonoBehaviour
{
    public GameObject dialoguePanel;
    public TextMeshProUGUI npcNameText;
    public TextMeshProUGUI dialogueText;

    private string[] currentLines;
    private float[] currentFontSizes;
    private int currentLineIndex;

    private TypewriterEffect typewriter;

    public Action onDialogueEnd;

    private float defaultFontSize = 18f;

    void Start()
    {
        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);

        if (dialogueText != null)
            dialogueText.fontSize = defaultFontSize;
    }

    void Update()
    {
        if (dialogueText != null && dialogueText.fontSize != defaultFontSize)
        {
            Debug.LogWarning("Font size was changed to: " + dialogueText.fontSize + " — forcing back to " + defaultFontSize);
            dialogueText.fontSize = defaultFontSize;
        }
    }

    public void StartDialogue(string npcName, string[] lines, float[] fontSizes = null)
    {
        dialoguePanel.SetActive(true);

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        CameraFollow cam = FindFirstObjectByType<CameraFollow>();
        if (cam != null)
            cam.canLook = false;

        npcNameText.text = npcName;
        currentLines = lines;
        currentFontSizes = fontSizes;
        currentLineIndex = 0;

        typewriter = dialogueText.GetComponent<TypewriterEffect>();

        if (currentFontSizes != null && currentFontSizes.Length > 0)
            dialogueText.fontSize = currentFontSizes[0];
        else
            dialogueText.fontSize = defaultFontSize;

        DisplayLine(currentLineIndex);
    }

    void DisplayLine(int index)
    {
        if (currentFontSizes != null && index < currentFontSizes.Length)
            dialogueText.fontSize = currentFontSizes[index];
        else
            dialogueText.fontSize = defaultFontSize;

        if (typewriter != null)
            typewriter.PlayText(currentLines[index]);
        else
            dialogueText.text = currentLines[index];
    }

    public void ShowNextLine()
    {
        if (typewriter != null && typewriter.IsTyping())
        {
            typewriter.SkipToEnd(currentLines[currentLineIndex]);
            return;
        }

        currentLineIndex++;

        if (currentLineIndex < currentLines.Length)
            DisplayLine(currentLineIndex);
        else
            EndDialogue();
    }

    public void EndDialogue()
    {
        dialoguePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        CameraFollow cam = FindFirstObjectByType<CameraFollow>();
        if (cam != null)
            cam.canLook = true;

        PlayerInteraction playerInteraction = FindFirstObjectByType<PlayerInteraction>();
        if (playerInteraction != null)
            playerInteraction.EndInteraction();

        onDialogueEnd?.Invoke();
        onDialogueEnd = null;
    }
}