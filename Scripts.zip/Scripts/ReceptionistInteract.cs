using UnityEngine;
using System.Collections;

public class ReceptionistInteract : MonoBehaviour, IInteractable
{
    public string npcName = "Receptionist";

    [TextArea(2, 5)]
    public string[] dialogueLines;

    public GameObject bossCheckpoint;

    public float[] dialogueFontSizes = new float[]
    {
        18f, 
        18f,  
        18f, 
        18f,  
        18f,  
    };

    private Animator animator;
    private DialogueManager dialogueManager;
    private bool hasTalked = false;

    void Start()
    {
        animator = GetComponent<Animator>();
        dialogueManager = FindFirstObjectByType<DialogueManager>();

        if (bossCheckpoint != null)
            bossCheckpoint.SetActive(false);
    }

    public void Interact()
    {
        if (hasTalked) return;

        hasTalked = true;

        if (animator != null)
            animator.SetBool("IsTalking", true);

        dialogueManager.onDialogueEnd = OnReceptionistDialogueEnded;

        if (dialogueManager != null)
            dialogueManager.StartDialogue(npcName, dialogueLines, dialogueFontSizes);
    }

    void OnReceptionistDialogueEnded()
    {
        if (animator != null)
            animator.SetBool("IsTalking", false);

        if (bossCheckpoint != null)
            bossCheckpoint.SetActive(true);

        Debug.Log("Receptionist finished. Boss checkpoint is now active.");
    }
}