using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;
    private AudioSource audioSource;
    private bool musicStarted = false;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        // Start music on first click or keypress
        if (!musicStarted && (Input.anyKeyDown ||
            Input.GetMouseButtonDown(0)))
        {
            audioSource.Play();
            musicStarted = true;
        }
    }

    public void SetVolume(float volume)
    {
        if (audioSource != null)
            audioSource.volume = volume;
    }

    public void StopMusic()
    {
        if (audioSource != null)
            audioSource.Stop();
    }
}