using UnityEngine;
using TMPro;
using System.Collections;

public class TypewriterEffect : MonoBehaviour
{
    private TextMeshProUGUI textComponent;
    private Coroutine typingCoroutine;
    private bool isCurrentlyTyping = false;

    public float typingSpeed = 0.03f;

    void Awake()
    {
        textComponent = GetComponent<TextMeshProUGUI>();
    }

    public void PlayText(string fullText)
    {
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        typingCoroutine = StartCoroutine(TypeText(fullText));
    }

    IEnumerator TypeText(string fullText)
    {
        isCurrentlyTyping = true;
        textComponent.text = "";

        foreach (char letter in fullText)
        {
            textComponent.text += letter;
            yield return new WaitForSeconds(typingSpeed);
        }

        isCurrentlyTyping = false;
        typingCoroutine = null;
    }

    public void SkipToEnd(string fullText)
    {
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        typingCoroutine = null;
        isCurrentlyTyping = false;
        textComponent.text = fullText;
    }

    public bool IsTyping()
    {
        return isCurrentlyTyping;
    }
}