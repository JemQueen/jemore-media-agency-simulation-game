using UnityEngine;
using UnityEngine.SceneManagement;

public class EndSceneManager : MonoBehaviour
{
    public string mainMenuSceneName = "MainMenu Scene";
    public string gameSceneName = "Demo 1 - Office Set 1";

    public void OnRestartPressed()
    {
        SceneManager.LoadScene(gameSceneName);
    }

    public void OnMainMenuPressed()
    {
        SceneManager.LoadScene(mainMenuSceneName);
    }
}